"use strict";
(self["webpackChunkeasy_locker_angular"] = self["webpackChunkeasy_locker_angular"] || []).push([["main"],{

/***/ 8439:
/*!**************************************************!*\
  !*** ./src/app/animations/dropdown.animation.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dropdownAnimation: () => (/* binding */ dropdownAnimation)
/* harmony export */ });
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/animations */ 7172);

const dropdownAnimation = (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.trigger)('dropdownAnimation', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.transition)(':enter', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({
  opacity: 0,
  transform: 'translateY(-4px)'
}), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)('180ms ease-out', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({
  opacity: 1,
  transform: 'translateY(0)'
}))]), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.transition)(':leave', [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)('160ms ease-in', (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({
  opacity: 0,
  transform: 'translateY(-4px)'
}))])]);

/***/ }),

/***/ 4114:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppRoutingModule: () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var _pages_home_home_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages/home/home.component */ 5047);
/* harmony import */ var _pages_cookie_policy_cookie_policy_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/cookie-policy/cookie-policy.component */ 4199);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7580);





const routes = [{
  path: '',
  component: _pages_home_home_component__WEBPACK_IMPORTED_MODULE_0__.HomeComponent
}, {
  path: 'politica-cookies',
  component: _pages_cookie_policy_cookie_policy_component__WEBPACK_IMPORTED_MODULE_1__.CookiePolicyComponent
}, {
  path: '**',
  redirectTo: ''
}];
class AppRoutingModule {
  static {
    this.ɵfac = function AppRoutingModule_Factory(t) {
      return new (t || AppRoutingModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({
      type: AppRoutingModule
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forRoot(routes, {
        scrollPositionRestoration: 'top',
        anchorScrolling: 'enabled'
      }), _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](AppRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
  });
})();

/***/ }),

/***/ 92:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppComponent: () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 819);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 1567);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 3900);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _services_language_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./services/language.service */ 8756);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser */ 436);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 852);
/* harmony import */ var _core_services_cookie_consent_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./core/services/cookie-consent.service */ 1845);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _shared_components_cookie_banner_cookie_banner_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./shared/components/cookie-banner/cookie-banner.component */ 5109);











function AppComponent_app_cookie_banner_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "app-cookie-banner");
  }
}
class AppComponent {
  constructor(languageService, titleService, metaService, translate, router, cookieConsent) {
    this.languageService = languageService;
    this.titleService = titleService;
    this.metaService = metaService;
    this.translate = translate;
    this.router = router;
    this.cookieConsent = cookieConsent;
    this.title = 'easy-locker-angular';
    this.destroy$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__.Subject();
  }
  ngOnInit() {
    this.languageService.init();
    this.updateSeo();
    this.router.events.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.filter)(event => event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_6__.NavigationEnd), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this.destroy$)).subscribe(() => this.updateSeo());
    this.translate.onLangChange.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.takeUntil)(this.destroy$)).subscribe(() => this.updateSeo());
  }
  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }
  updateSeo() {
    const seoTitle = this.translate.instant('seo.home.title');
    const seoDescription = this.translate.instant('seo.home.description');
    const seoKeywords = this.translate.instant('seo.home.keywords');
    this.titleService.setTitle(seoTitle);
    this.metaService.updateTag({
      name: 'description',
      content: seoDescription
    });
    this.metaService.updateTag({
      name: 'keywords',
      content: seoKeywords
    });
    this.metaService.updateTag({
      property: 'og:title',
      content: seoTitle
    });
    this.metaService.updateTag({
      property: 'og:description',
      content: seoDescription
    });
    this.metaService.updateTag({
      name: 'twitter:title',
      content: seoTitle
    });
    this.metaService.updateTag({
      name: 'twitter:description',
      content: seoDescription
    });
  }
  static {
    this.ɵfac = function AppComponent_Factory(t) {
      return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_language_service__WEBPACK_IMPORTED_MODULE_0__.LanguageService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__.Title), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__.Meta), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_core_services_cookie_consent_service__WEBPACK_IMPORTED_MODULE_1__.CookieConsentService));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
      type: AppComponent,
      selectors: [["app-root"]],
      decls: 4,
      vars: 1,
      consts: [[1, "min-h-screen", "font-sans", "bg-brand-background", "transition-colors", "duration-300"], [1, "bg-brand-background", 2, "display", "none"], [4, "ngIf"]],
      template: function AppComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "main", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](1, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](2, AppComponent_app_cookie_banner_2_Template, 1, 0, "app-cookie-banner", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](3, "router-outlet");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx.cookieConsent.hasAnswered);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.NgIf, _angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterOutlet, _shared_components_cookie_banner_cookie_banner_component__WEBPACK_IMPORTED_MODULE_2__.CookieBannerComponent],
      styles: ["/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAuY29tcG9uZW50LmNzcyJ9 */\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUNBLDRKQUE0SiIsInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 635:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppModule: () => (/* binding */ AppModule),
/* harmony export */   HttpLoaderFactory: () => (/* binding */ HttpLoaderFactory)
/* harmony export */ });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/platform-browser */ 436);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common/http */ 6443);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app-routing.module */ 4114);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component */ 92);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ngx-translate/core */ 852);
/* harmony import */ var _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngx-translate/http-loader */ 8952);
/* harmony import */ var _components_header_header_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/header/header.component */ 385);
/* harmony import */ var _components_hero_hero_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/hero/hero.component */ 9307);
/* harmony import */ var _components_faq_faq_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/faq/faq.component */ 9613);
/* harmony import */ var _components_footer_footer_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/footer/footer.component */ 5473);
/* harmony import */ var _components_language_switcher_language_switcher_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/language-switcher/language-switcher.component */ 5457);
/* harmony import */ var _components_pricing_pricing_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/pricing/pricing.component */ 2185);
/* harmony import */ var _components_testimonials_testimonials_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./components/testimonials/testimonials.component */ 5375);
/* harmony import */ var _pages_home_home_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./pages/home/home.component */ 5047);
/* harmony import */ var _shared_components_cookie_banner_cookie_banner_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./shared/components/cookie-banner/cookie-banner.component */ 5109);
/* harmony import */ var _shared_components_cookie_preferences_cookie_preferences_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./shared/components/cookie-preferences/cookie-preferences.component */ 6841);
/* harmony import */ var _pages_cookie_policy_cookie_policy_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./pages/cookie-policy/cookie-policy.component */ 4199);
/* harmony import */ var _shared_components_easy_card_easy_card_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./shared/components/easy-card/easy-card.component */ 3277);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 7580);





















function HttpLoaderFactory(http) {
  return new _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_14__.TranslateHttpLoader(http, './assets/i18n/', '.json');
}
class AppModule {
  static {
    this.ɵfac = function AppModule_Factory(t) {
      return new (t || AppModule)();
    };
  }
  static {
    this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineNgModule"]({
      type: AppModule,
      bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent]
    });
  }
  static {
    this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineInjector"]({
      imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__.BrowserModule, _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_17__.HttpClientModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__.TranslateModule.forRoot({
        loader: {
          provide: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__.TranslateLoader,
          useFactory: HttpLoaderFactory,
          deps: [_angular_common_http__WEBPACK_IMPORTED_MODULE_17__.HttpClient]
        },
        defaultLanguage: 'es'
      })]
    });
  }
}
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵsetNgModuleScope"](AppModule, {
    declarations: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent, _components_header_header_component__WEBPACK_IMPORTED_MODULE_2__.HeaderComponent, _components_hero_hero_component__WEBPACK_IMPORTED_MODULE_3__.HeroComponent, _components_faq_faq_component__WEBPACK_IMPORTED_MODULE_4__.FaqComponent, _components_footer_footer_component__WEBPACK_IMPORTED_MODULE_5__.FooterComponent, _components_language_switcher_language_switcher_component__WEBPACK_IMPORTED_MODULE_6__.LanguageSwitcherComponent, _components_pricing_pricing_component__WEBPACK_IMPORTED_MODULE_7__.PricingComponent, _components_testimonials_testimonials_component__WEBPACK_IMPORTED_MODULE_8__.TestimonialsComponent, _pages_home_home_component__WEBPACK_IMPORTED_MODULE_9__.HomeComponent, _shared_components_cookie_banner_cookie_banner_component__WEBPACK_IMPORTED_MODULE_10__.CookieBannerComponent, _shared_components_cookie_preferences_cookie_preferences_component__WEBPACK_IMPORTED_MODULE_11__.CookiePreferencesComponent, _pages_cookie_policy_cookie_policy_component__WEBPACK_IMPORTED_MODULE_12__.CookiePolicyComponent, _shared_components_easy_card_easy_card_component__WEBPACK_IMPORTED_MODULE_13__.EasyCardComponent],
    imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_16__.BrowserModule, _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_17__.HttpClientModule, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_18__.TranslateModule]
  });
})();

/***/ }),

/***/ 9613:
/*!*************************************************!*\
  !*** ./src/app/components/faq/faq.component.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FaqComponent: () => (/* binding */ FaqComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _core_analytics_analytics_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core/analytics/analytics.service */ 7854);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ 852);




const _c0 = function (a0, a1) {
  return {
    "easy-faq-item--open": a0,
    "easy-faq-item--hover": a1
  };
};
const _c1 = function (a0) {
  return {
    "easy-faq-chevron--open": a0
  };
};
const _c2 = function (a0, a1) {
  return {
    "max-h-0 opacity-0": a0,
    "max-h-96 opacity-100 mt-3": a1
  };
};
function FaqComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 8)(1, "article", 9)(2, "button", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function FaqComponent_div_11_Template_button_click_2_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r4);
      const i_r2 = restoredCtx.index;
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r3.toggleFaq(i_r2));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "div", 11)(4, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "span", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](8, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "svg", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](11, "path", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnamespaceHTML"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "div", 17)(13, "p", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](15, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const faq_r1 = ctx.$implicit;
    const i_r2 = ctx.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction2"](17, _c0, faq_r1.isOpen, !faq_r1.isOpen));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("id", "faq-header-" + i_r2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵattribute"]("aria-expanded", faq_r1.isOpen)("aria-controls", "faq-panel-" + i_r2)("data-testid", "faq-toggle-" + i_r2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", i_r2 + 1, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](8, 13, faq_r1.questionKey), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction1"](20, _c1, faq_r1.isOpen));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("id", "faq-panel-" + i_r2)("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction2"](22, _c2, !faq_r1.isOpen, faq_r1.isOpen));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵattribute"]("aria-labelledby", "faq-header-" + i_r2)("data-testid", "faq-answer-" + i_r2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](15, 15, faq_r1.answerKey), " ");
  }
}
class FaqComponent {
  constructor(analytics, elementRef) {
    this.analytics = analytics;
    this.elementRef = elementRef;
    this.faqs = [{
      questionKey: 'faq_q1',
      answerKey: 'faq_a1',
      isOpen: false
    }, {
      questionKey: 'faq_q2',
      answerKey: 'faq_a2',
      isOpen: false
    }, {
      questionKey: 'faq_q3',
      answerKey: 'faq_a3',
      isOpen: false
    }, {
      questionKey: 'faq_q4',
      answerKey: 'faq_a4',
      isOpen: false
    }, {
      questionKey: 'faq_q5',
      answerKey: 'faq_a5',
      isOpen: false
    }, {
      questionKey: 'faq_q6',
      answerKey: 'faq_a6',
      isOpen: false
    }, {
      questionKey: 'faq_q7',
      answerKey: 'faq_a7',
      isOpen: false
    }, {
      questionKey: 'faq_q8',
      answerKey: 'faq_a8',
      isOpen: false
    }, {
      questionKey: 'faq_q9',
      answerKey: 'faq_a9',
      isOpen: false
    }];
    this.hasLoggedView = false;
  }
  ngAfterViewInit() {
    this.observeFaqSection();
  }
  ngOnDestroy() {
    this.observer?.disconnect();
  }
  toggleFaq(index) {
    const faq = this.faqs[index];
    faq.isOpen = !faq.isOpen;
    this.analytics.trackEvent('faq_toggle', {
      faq_id: index,
      faq_question_key: faq.questionKey,
      is_open: faq.isOpen
    });
  }
  observeFaqSection() {
    if (typeof window === 'undefined') {
      return;
    }
    if (!('IntersectionObserver' in window)) {
      this.logFaqView();
      return;
    }
    this.observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          this.logFaqView();
        }
      });
    }, {
      threshold: 0.3
    });
    this.observer.observe(this.elementRef.nativeElement);
  }
  logFaqView() {
    if (this.hasLoggedView) {
      return;
    }
    this.hasLoggedView = true;
    this.analytics.trackEvent('faq_view', {
      faq_count: this.faqs.length
    });
    this.observer?.disconnect();
  }
  static {
    this.ɵfac = function FaqComponent_Factory(t) {
      return new (t || FaqComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_core_analytics_analytics_service__WEBPACK_IMPORTED_MODULE_0__.AnalyticsService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.ElementRef));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: FaqComponent,
      selectors: [["app-faq"]],
      decls: 12,
      vars: 7,
      consts: [[1, "py-16", "lg:py-24", "text-brand-textPrimary", "font-sans", "transition-colors", "duration-300"], [1, "container", "mx-auto", "px-6", "lg:px-8"], [1, "section-heading", "text-center", "max-w-4xl", "mx-auto", "mb-10", "md:mb-12"], [1, "text-3xl", "md:text-4xl", "lg:text-5xl", "font-bold", "text-brand-textPrimary", "text-center", "dark:text-brand-darkTextStrong"], [1, "mt-2", "text-base", "md:text-lg", "text-brand-textSecondary", "text-center", "max-w-xl", "mx-auto"], [1, "easy-section-underline"], [1, "max-w-4xl", "mx-auto", "space-y-4"], ["class", "group", 4, "ngFor", "ngForOf"], [1, "group"], [1, "easy-faq-item", "group", 3, "ngClass"], ["type", "button", 1, "easy-faq-header", "easy-focus-reset", "easy-focus-ring", 3, "id", "click"], [1, "flex", "items-center", "gap-4"], [1, "easy-faq-step-badge", "mr-4"], [1, "easy-faq-title"], [1, "easy-faq-chevron", 3, "ngClass"], ["fill", "none", "stroke", "currentColor", "viewBox", "0 0 24 24", 1, "w-5", "h-5"], ["stroke-linecap", "round", "stroke-linejoin", "round", "stroke-width", "2", "d", "M19 9l-7 7-7-7"], ["role", "region", 1, "overflow-hidden", "transition-all", "duration-200", "ease-out", 3, "id", "ngClass"], [1, "easy-faq-body"]],
      template: function FaqComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "header", 2)(3, "h2", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](5, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "p", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](8, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](9, "div", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "div", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, FaqComponent_div_11_Template, 16, 25, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](5, 3, "sections.faq.title"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](8, 5, "sections.faq.subtitle"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.faqs);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslatePipe],
      styles: ["/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmYXEuY29tcG9uZW50LmNzcyJ9 */\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy9mYXEvZmFxLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUNBLDRKQUE0SiIsInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 2499:
/*!***************************************************!*\
  !*** ./src/app/components/footer/footer-icons.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FOOTER_LINK_ICONS: () => (/* binding */ FOOTER_LINK_ICONS),
/* harmony export */   FOOTER_SOCIAL_ICONS: () => (/* binding */ FOOTER_SOCIAL_ICONS),
/* harmony export */   SecureIcon: () => (/* binding */ SecureIcon)
/* harmony export */ });
const FOOTER_SOCIAL_ICONS = {
  facebook: `
		<svg
			viewBox="0 0 24 24"
			aria-hidden="true"
			focusable="false"
			xmlns="http://www.w3.org/2000/svg"
			width="24"
			height="24"
			class="w-5 h-5"
		>
			<path
				fill="currentColor"
				d="M9.101 23.691v-7.98H6.627v-3.667h2.474v-1.58c0-4.085 1.848-5.978 5.858-5.978.401 0 .955.042 1.468.103a8.68 8.68 0 0 1 1.141.195v3.325a8.623 8.623 0 0 0-.653-.036 26.805 26.805 0 0 0-.733-.009c-.707 0-1.259.096-1.675.309a1.686 1.686 0 0 0-.679.622c-.258.42-.374.995-.374 1.752v1.297h3.919l-.386 2.103-.287 1.564h-3.246v8.245C19.396 23.238 24 18.179 24 12.044c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.628 3.874 10.35 9.101 11.647Z"
			/>
		</svg>
	`,
  instagram: `
		<svg
			viewBox="0 0 24 24"
			aria-hidden="true"
			focusable="false"
			xmlns="http://www.w3.org/2000/svg"
			width="24"
			height="24"
			class="w-5 h-5"
		>
			<path
				fill="currentColor"
				d="M7.0301.084c-1.2768.0602-2.1487.264-2.911.5634-.7888.3075-1.4575.72-2.1228 1.3877-.6652.6677-1.075 1.3368-1.3802 2.127-.2954.7638-.4956 1.6365-.552 2.914-.0564 1.2775-.0689 1.6882-.0626 4.947.0062 3.2586.0206 3.6671.0825 4.9473.061 1.2765.264 2.1482.5635 2.9107.308.7889.72 1.4573 1.388 2.1228.6679.6655 1.3365 1.0743 2.1285 1.38.7632.295 1.6361.4961 2.9134.552 1.2773.056 1.6884.069 4.9462.0627 3.2578-.0062 3.668-.0207 4.9478-.0814 1.28-.0607 2.147-.2652 2.9098-.5633.7889-.3086 1.4578-.72 2.1228-1.3881.665-.6682 1.0745-1.3378 1.3795-2.1284.2957-.7632.4966-1.636.552-2.9124.056-1.2809.0692-1.6898.063-4.948-.0063-3.2583-.021-3.6668-.0817-4.9465-.0607-1.2797-.264-2.1487-.5633-2.9117-.3084-.7889-.72-1.4568-1.3876-2.1228C21.2982 1.33 20.628.9208 19.8378.6165 19.074.321 18.2017.1197 16.9244.0645 15.6471.0093 15.236-.005 11.977.0014 8.718.0076 8.31.0215 7.0301.0839m.1402 21.6932c-1.17-.0509-1.8053-.2453-2.2287-.408-.5606-.216-.96-.4771-1.3819-.895-.422-.4178-.6811-.8186-.9-1.378-.1644-.4234-.3624-1.058-.4171-2.228-.0595-1.2645-.072-1.6442-.079-4.848-.007-3.2037.0053-3.583.0607-4.848.05-1.169.2456-1.805.408-2.2282.216-.5613.4762-.96.895-1.3816.4188-.4217.8184-.6814 1.3783-.9003.423-.1651 1.0575-.3614 2.227-.4171 1.2655-.06 1.6447-.072 4.848-.079 3.2033-.007 3.5835.005 4.8495.0608 1.169.0508 1.8053.2445 2.228.408.5608.216.96.4754 1.3816.895.4217.4194.6816.8176.9005 1.3787.1653.4217.3617 1.056.4169 2.2263.0602 1.2655.0739 1.645.0796 4.848.0058 3.203-.0055 3.5834-.061 4.848-.051 1.17-.245 1.8055-.408 2.2294-.216.5604-.4763.96-.8954 1.3814-.419.4215-.8181.6811-1.3783.9-.4224.1649-1.0577.3617-2.2262.4174-1.2656.0595-1.6448.072-4.8493.079-3.2045.007-3.5825-.006-4.848-.0608M16.953 5.5864A1.44 1.44 0 1 0 18.39 4.144a1.44 1.44 0 0 0-1.437 1.4424M5.8385 12.012c.0067 3.4032 2.7706 6.1557 6.173 6.1493 3.4026-.0065 6.157-2.7701 6.1506-6.1733-.0065-3.4032-2.771-6.1565-6.174-6.1498-3.403.0067-6.156 2.771-6.1496 6.1738M8 12.0077a4 4 0 1 1 4.008 3.9921A3.9996 3.9996 0 0 1 8 12.0077"
			/>
		</svg>
	`,
  tiktok: `
		<svg
			viewBox="0 0 24 24"
			aria-hidden="true"
			focusable="false"
			xmlns="http://www.w3.org/2000/svg"
			width="24"
			height="24"
			class="w-5 h-5"
		>
			<path
				fill="currentColor"
				d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"
			/>
		</svg>
	`
};
const FOOTER_LINK_ICONS = {
  email: `
		<svg
			viewBox="0 0 24 24"
			aria-hidden="true"
			focusable="false"
			xmlns="http://www.w3.org/2000/svg"
			width="24"
			height="24"
			class="w-5 h-5"
		>
			<path
				fill="currentColor"
				d="M1.5 8.67v8.58a3 3 0 0 0 3 3h15a3 3 0 0 0 3-3V8.67l-8.928 5.493a3 3 0 0 1-3.144 0L1.5 8.67Z"
			/>
			<path
				fill="currentColor"
				d="M22.5 6.908V6.75a3 3 0 0 0-3-3h-15a3 3 0 0 0-3 3v.158l9.714 5.978a1.5 1.5 0 0 0 1.572 0L22.5 6.908Z"
			/>
		</svg>
	`,
  terms: `
		<svg
			viewBox="0 0 24 24"
			aria-hidden="true"
			focusable="false"
			xmlns="http://www.w3.org/2000/svg"
			width="24"
			height="24"
			class="w-5 h-5"
		>
			<path
				fill="currentColor"
				fill-rule="evenodd"
				clip-rule="evenodd"
				d="M5.625 1.5c-1.036 0-1.875.84-1.875 1.875v17.25c0 1.035.84 1.875 1.875 1.875h12.75c1.035 0 1.875-.84 1.875-1.875V12.75A3.75 3.75 0 0 0 16.5 9h-1.875a1.875 1.875 0 0 1-1.875-1.875V5.25A3.75 3.75 0 0 0 9 1.5H5.625ZM7.5 15a.75.75 0 0 1 .75-.75h7.5a.75.75 0 0 1 0 1.5h-7.5A.75.75 0 0 1 7.5 15Zm.75 2.25a.75.75 0 0 0 0 1.5H12a.75.75 0 0 0 0-1.5H8.25Z"
			/>
			<path
				fill="currentColor"
				d="M12.971 1.816A5.23 5.23 0 0 1 14.25 5.25v1.875c0 .207.168.375.375.375H16.5a5.23 5.23 0 0 1 3.434 1.279 9.768 9.768 0 0 0-6.963-6.963Z"
			/>
		</svg>
	`,
  cookies: `
		<svg
			viewBox="0 0 24 24"
			aria-hidden="true"
			focusable="false"
			xmlns="http://www.w3.org/2000/svg"
			width="24"
			height="24"
			class="w-5 h-5"
		>
			<path
				fill="currentColor"
				d="M12 3a9 9 0 0 0-9 9 9 9 0 0 0 9 9 9 9 0 0 0 9-9c0-.5-.04-1-.13-1.5-.27-.5-.87-.5-.87-.5H18V9c0-1-1-1-1-1h-2V7c0-1-1-1-1-1h-1V4c0-1-1-1-1-1ZM9.5 6A1.5 1.5 0 1 1 11 7.5 1.5 1.5 0 0 1 9.5 6Zm-3 4A1.5 1.5 0 1 1 8 11.5 1.5 1.5 0 0 1 6.5 10Zm5 1A1.5 1.5 0 1 1 13 12.5 1.5 1.5 0 0 1 11.5 11Zm5 2A1.5 1.5 0 1 1 18 14.5 1.5 1.5 0 0 1 16.5 16a1.5 1.5 0 0 1-1.5-1.5A1.5 1.5 0 0 1 16.5 13Zm-5 3A1.5 1.5 0 1 1 13 17.5 1.5 1.5 0 0 1 11.5 16Z"
			/>
		</svg>
	`,
  whatsapp: `
		<svg
			viewBox="0 0 24 24"
			aria-hidden="true"
			focusable="false"
			xmlns="http://www.w3.org/2000/svg"
			width="24"
			height="24"
			class="w-5 h-5"
		>
			<path
				fill="currentColor"
				d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"
			/>
		</svg>
	`
};
// Secure icon
const SecureIcon = `<svg class='w-4 h-4' fill='currentColor' viewBox='0 0 20 20'><path fill-rule='evenodd' d='M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z' clip-rule='evenodd'></path></svg>`;

/***/ }),

/***/ 5473:
/*!*******************************************************!*\
  !*** ./src/app/components/footer/footer.component.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FooterComponent: () => (/* binding */ FooterComponent)
/* harmony export */ });
/* harmony import */ var _footer_icons__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./footer-icons */ 2499);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ 852);
/* harmony import */ var _services_theme_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/theme.service */ 487);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ 436);
/* harmony import */ var _core_analytics_analytics_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../core/analytics/analytics.service */ 7854);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var _shared_components_cookie_preferences_cookie_preferences_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/components/cookie-preferences/cookie-preferences.component */ 6841);









function FooterComponent_img_6_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "img", 30);
  }
}
function FooterComponent_img_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "img", 31);
  }
}
function FooterComponent_app_cookie_preferences_86_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "app-cookie-preferences", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("closed", function FooterComponent_app_cookie_preferences_86_Template_app_cookie_preferences_closed_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r4);
      const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r3.onPreferencesClosed());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
const _c0 = function () {
  return {
    default: "Pol\u00EDtica de cookies"
  };
};
const _c1 = function () {
  return {
    default: "Gestionar cookies"
  };
};
class FooterComponent {
  constructor(translate, themeService, sanitizer, analytics) {
    this.translate = translate;
    this.themeService = themeService;
    this.sanitizer = sanitizer;
    this.analytics = analytics;
    this.currentYear = new Date().getFullYear();
    this.isDarkMode = false;
    this.showCookiePreferences = false;
    this.themeService.darkMode$.subscribe(isDark => {
      this.isDarkMode = isDark;
    });
    this.socialIcons = {
      facebook: this.sanitizer.bypassSecurityTrustHtml(_footer_icons__WEBPACK_IMPORTED_MODULE_0__.FOOTER_SOCIAL_ICONS.facebook),
      instagram: this.sanitizer.bypassSecurityTrustHtml(_footer_icons__WEBPACK_IMPORTED_MODULE_0__.FOOTER_SOCIAL_ICONS.instagram),
      tiktok: this.sanitizer.bypassSecurityTrustHtml(_footer_icons__WEBPACK_IMPORTED_MODULE_0__.FOOTER_SOCIAL_ICONS.tiktok)
    };
    this.linkIcons = {
      email: this.sanitizer.bypassSecurityTrustHtml(_footer_icons__WEBPACK_IMPORTED_MODULE_0__.FOOTER_LINK_ICONS.email),
      terms: this.sanitizer.bypassSecurityTrustHtml(_footer_icons__WEBPACK_IMPORTED_MODULE_0__.FOOTER_LINK_ICONS.terms),
      cookies: this.sanitizer.bypassSecurityTrustHtml(_footer_icons__WEBPACK_IMPORTED_MODULE_0__.FOOTER_LINK_ICONS.cookies),
      whatsapp: this.sanitizer.bypassSecurityTrustHtml(_footer_icons__WEBPACK_IMPORTED_MODULE_0__.FOOTER_LINK_ICONS.whatsapp)
    };
    this.secureIcon = this.sanitizer.bypassSecurityTrustHtml(_footer_icons__WEBPACK_IMPORTED_MODULE_0__.SecureIcon);
  }
  getTermsUrl() {
    const lang = this.translate.currentLang || 'es';
    switch (lang) {
      case 'en':
        return 'https://easylocker.drop-point.com/booking-engine/legal?locale=en';
      case 'fr':
        return 'https://easylocker.drop-point.com/booking-engine/legal?locale=fr';
      case 'de':
        return 'https://easylocker.drop-point.com/booking-engine/legal?locale=de';
      case 'it':
        return 'https://easylocker.drop-point.com/booking-engine/legal?locale=it';
      case 'es':
      default:
        return 'https://easylocker.drop-point.com/booking-engine/legal?locale=es';
    }
  }
  onQuickLinkClick(linkType, href) {
    this.analytics.trackEvent('footer_click_quick_link', {
      link_type: linkType,
      href
    });
  }
  onSocialClick(network, href) {
    this.analytics.trackEvent('footer_click_social', {
      network,
      href
    });
  }
  onManageCookies() {
    this.showCookiePreferences = true;
    this.analytics.trackEvent('footer_manage_cookies_open');
  }
  onPreferencesClosed() {
    this.showCookiePreferences = false;
  }
  static {
    this.ɵfac = function FooterComponent_Factory(t) {
      return new (t || FooterComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_theme_service__WEBPACK_IMPORTED_MODULE_1__.ThemeService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__.DomSanitizer), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_core_analytics_analytics_service__WEBPACK_IMPORTED_MODULE_2__.AnalyticsService));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
      type: FooterComponent,
      selectors: [["app-footer"]],
      decls: 87,
      vars: 62,
      consts: [[1, "bg-brand-background", "text-brand-textSecondary"], [1, "border-t", "border-brand-borderSubtle/70"], [1, "container", "mx-auto", "px-4", "lg:px-6", "py-10", "lg:py-12"], [1, "grid", "gap-10", "md:grid-cols-[1.3fr,1fr,1fr]", "lg:grid-cols-[1.4fr,1fr,1fr]", "items-start"], [1, "space-y-4", "text-center", "md:text-left"], [1, "flex", "justify-center", "md:justify-start"], ["src", "assets/images/landscape-light.svg", "alt", "Easy Locker", "class", "h-12 w-auto", 4, "ngIf"], ["src", "assets/images/landscape-dark.svg", "alt", "Easy Locker", "class", "h-12 w-auto", 4, "ngIf"], [1, "max-w-sm", "text-sm", "leading-relaxed", "text-brand-textSecondary", "mx-auto", "md:mx-0"], [1, "space-y-4"], [1, "text-xs", "font-semibold", "tracking-[0.18em]", "uppercase", "text-brand-textMuted"], [1, "space-y-3", "text-sm"], ["href", "mailto:info@easy-locker.com", 1, "group", "inline-flex", "items-center", "gap-2", "text-brand-textSecondary", "hover:text-brand-textPrimary", "transition-colors", "duration-150", "focus:outline-none", "focus-visible:ring-2", "focus-visible:ring-easy-indicator", "focus-visible:ring-offset-2", "focus-visible:ring-offset-brand-background", "rounded-full", "px-0.5", "-mx-0.5", 3, "click"], [1, "inline-flex", "h-5", "w-5", "items-center", "justify-center", "text-brand-iconMuted", "transition-colors", "duration-150", "group-hover:text-brand-textPrimary", 3, "innerHTML"], ["target", "_blank", "rel", "noopener noreferrer", 1, "group", "inline-flex", "items-center", "gap-2", "text-brand-textSecondary", "hover:text-brand-textPrimary", "transition-colors", "duration-150", "focus:outline-none", "focus-visible:ring-2", "focus-visible:ring-easy-indicator", "focus-visible:ring-offset-2", "focus-visible:ring-offset-brand-background", "rounded-full", "px-0.5", "-mx-0.5", 3, "href", "click"], ["routerLink", "/politica-cookies", 1, "group", "inline-flex", "items-center", "gap-2", "text-brand-textSecondary", "hover:text-brand-textPrimary", "transition-colors", "duration-150", "focus:outline-none", "focus-visible:ring-2", "focus-visible:ring-easy-indicator", "focus-visible:ring-offset-2", "focus-visible:ring-offset-brand-background", "rounded-full", "px-0.5", "-mx-0.5", 3, "click"], ["href", "https://wa.me/34665922538", "target", "_blank", "rel", "noopener noreferrer", 1, "group", "inline-flex", "items-center", "gap-2", "text-brand-textSecondary", "hover:text-brand-textPrimary", "transition-colors", "duration-150", "focus:outline-none", "focus-visible:ring-2", "focus-visible:ring-easy-indicator", "focus-visible:ring-offset-2", "focus-visible:ring-offset-brand-background", "rounded-full", "px-0.5", "-mx-0.5", 3, "click"], [1, "space-y-2", "text-sm"], ["href", "https://www.facebook.com/share/1Got7XaYUE/?mibextid=wwXIfr", "target", "_blank", "rel", "noopener noreferrer", 1, "group", "inline-flex", "items-center", "gap-2", "text-brand-textSecondary", "hover:text-brand-textPrimary", "transition-colors", "duration-150", "focus:outline-none", "focus-visible:ring-2", "focus-visible:ring-easy-indicator", "focus-visible:ring-offset-2", "focus-visible:ring-offset-brand-background", "rounded-full", "px-0.5", "-mx-0.5", 3, "click"], ["href", "https://www.instagram.com/easylocker.es", "target", "_blank", "rel", "noopener noreferrer", 1, "group", "inline-flex", "items-center", "gap-2", "text-brand-textSecondary", "hover:text-brand-textPrimary", "transition-colors", "duration-150", "focus:outline-none", "focus-visible:ring-2", "focus-visible:ring-easy-indicator", "focus-visible:ring-offset-2", "focus-visible:ring-offset-brand-background", "rounded-full", "px-0.5", "-mx-0.5", 3, "click"], ["href", "https://www.tiktok.com/@easylocker.es", "target", "_blank", "rel", "noopener noreferrer", 1, "group", "inline-flex", "items-center", "gap-2", "text-brand-textSecondary", "hover:text-brand-textPrimary", "transition-colors", "duration-150", "focus:outline-none", "focus-visible:ring-2", "focus-visible:ring-easy-indicator", "focus-visible:ring-offset-2", "focus-visible:ring-offset-brand-background", "rounded-full", "px-0.5", "-mx-0.5", 3, "click"], [1, "mt-8", "pt-6", "border-t", "border-brand-borderSubtle/60", "flex", "flex-col", "gap-4", "md:flex-row", "md:items-center", "md:justify-between", "text-xs", "text-brand-textMuted"], [1, "flex", "flex-wrap", "items-center", "gap-4", "text-brand-textSecondary"], [1, "inline-flex", "items-center", "gap-2"], [1, "inline-flex", "h-5", "w-5", "items-center", "justify-center", "rounded-full", "bg-brand-surface/5", "text-current", 3, "innerHTML"], [1, "hidden", "h-4", "w-px", "bg-brand-borderSubtle/60", "md:inline-block"], [1, "inline-flex", "items-center", "gap-1.5"], [1, "text-sm"], ["type", "button", 1, "easy-focus-reset", "underline", "decoration-dotted", "underline-offset-4", 3, "click"], [3, "closed", 4, "ngIf"], ["src", "assets/images/landscape-light.svg", "alt", "Easy Locker", 1, "h-12", "w-auto"], ["src", "assets/images/landscape-dark.svg", "alt", "Easy Locker", 1, "h-12", "w-auto"], [3, "closed"]],
      template: function FooterComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "footer", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3)(4, "div", 4)(5, "div", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](6, FooterComponent_img_6_Template, 1, 0, "img", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, FooterComponent_img_7_Template, 1, 0, "img", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "p", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](10, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div", 9)(12, "h3", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](14, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "ul", 11)(16, "li")(17, "a", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function FooterComponent_Template_a_click_17_listener() {
            return ctx.onQuickLinkClick("email", "mailto:info@easy-locker.com");
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](18, "span", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](20);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](21, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](22, "li")(23, "a", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function FooterComponent_Template_a_click_23_listener() {
            return ctx.onQuickLinkClick("terms", ctx.getTermsUrl());
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](24, "span", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](25, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](26);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](27, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](28, "li")(29, "a", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function FooterComponent_Template_a_click_29_listener() {
            return ctx.onQuickLinkClick("cookie-policy", "/politica-cookies");
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](30, "span", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](32);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](33, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](34, "li")(35, "a", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function FooterComponent_Template_a_click_35_listener() {
            return ctx.onQuickLinkClick("whatsapp", "https://wa.me/34665922538");
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](36, "span", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](37, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](38);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](39, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](40, "div", 9)(41, "h3", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](42);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](43, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](44, "ul", 17)(45, "li")(46, "a", 18);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function FooterComponent_Template_a_click_46_listener() {
            return ctx.onSocialClick("facebook", "https://www.facebook.com/share/1Got7XaYUE/?mibextid=wwXIfr");
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](47, "span", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](48, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](49);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](50, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](51, "li")(52, "a", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function FooterComponent_Template_a_click_52_listener() {
            return ctx.onSocialClick("instagram", "https://www.instagram.com/easylocker.es");
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](53, "span", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](54, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](55);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](56, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](57, "li")(58, "a", 20);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function FooterComponent_Template_a_click_58_listener() {
            return ctx.onSocialClick("tiktok", "https://www.tiktok.com/@easylocker.es");
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](59, "span", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](60, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](61);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](62, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](63, "div", 21)(64, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](65);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](66, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](67, "div", 22)(68, "div", 23);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](69, "span", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](70, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](71);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](72, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](73, "span", 25);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](74, "div", 26)(75, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](76);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](77, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](78, "span", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](79, "\u2764\uFE0F");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](80, "span");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](81);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](82, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](83, "button", 28);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function FooterComponent_Template_button_click_83_listener() {
            return ctx.onManageCookies();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](84);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](85, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](86, FooterComponent_app_cookie_preferences_86_Template, 1, 0, "app-cookie-preferences", 29);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.isDarkMode);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.isDarkMode);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](10, 28, "footer_description"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](14, 30, "footer_quick_links"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("innerHTML", ctx.linkIcons.email, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeHtml"]);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](21, 32, "footer_email"));
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("href", ctx.getTermsUrl(), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeUrl"]);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("innerHTML", ctx.linkIcons.terms, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeHtml"]);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](27, 34, "footer_terms"));
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("innerHTML", ctx.linkIcons.cookies, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeHtml"]);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](33, 36, "cookies.action.policy", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](60, _c0)), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("innerHTML", ctx.linkIcons.whatsapp, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeHtml"]);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](39, 39, "footer_whatsapp"));
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](43, 41, "footer_connect_title"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("innerHTML", ctx.socialIcons.facebook, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeHtml"]);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](50, 43, "footer_social.facebook"));
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("innerHTML", ctx.socialIcons.instagram, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeHtml"]);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](56, 45, "footer_social.instagram"));
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("innerHTML", ctx.socialIcons.tiktok, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeHtml"]);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](62, 47, "footer_social.tiktok"));
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate2"](" \u00A9 ", ctx.currentYear, " Easy Locker \u00B7 C\u00F3rdoba. ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](66, 49, "footer_all_rights"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("innerHTML", ctx.secureIcon, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsanitizeHtml"]);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](72, 51, "footer_badge_secure_service"));
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](77, 53, "footer_badge_made_with"));
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](82, 55, "footer_badge_in_cordoba"));
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](85, 57, "cookies.action.manage", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction0"](61, _c1)), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.showCookiePreferences);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _angular_router__WEBPACK_IMPORTED_MODULE_8__.RouterLink, _shared_components_cookie_preferences_cookie_preferences_component__WEBPACK_IMPORTED_MODULE_3__.CookiePreferencesComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__.TranslatePipe],
      styles: ["/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmb290ZXIuY29tcG9uZW50LmNzcyJ9 */\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy9mb290ZXIvZm9vdGVyLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUNBLGdLQUFnSyIsInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 385:
/*!*******************************************************!*\
  !*** ./src/app/components/header/header.component.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HeaderComponent: () => (/* binding */ HeaderComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 2510);
/* harmony import */ var _animations_dropdown_animation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../animations/dropdown.animation */ 8439);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _services_theme_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/theme.service */ 487);
/* harmony import */ var _services_dropdown_coordinator_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/dropdown-coordinator.service */ 3636);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _language_switcher_language_switcher_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../language-switcher/language-switcher.component */ 5457);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ 852);








function HeaderComponent_img_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "img", 16);
  }
}
function HeaderComponent_img_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "img", 17);
  }
}
function HeaderComponent__svg_svg_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "svg", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "path", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function HeaderComponent__svg_svg_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "svg", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "path", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function HeaderComponent__svg_svg_16_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "svg", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "path", 21)(2, "path", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
}
function HeaderComponent_div_22_button_2_span_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "span", 30);
  }
}
function HeaderComponent_div_22_button_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "button", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function HeaderComponent_div_22_button_2_Template_button_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r10);
      const option_r7 = restoredCtx.$implicit;
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r9.selectTheme(option_r7.value));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 26)(2, "span", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "span", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](8, HeaderComponent_div_22_button_2_span_8_Template, 1, 0, "span", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const option_r7 = ctx.$implicit;
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("header-picker-option--active", option_r7.value === ctx_r6.currentPreference);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵattribute"]("aria-selected", option_r7.value === ctx_r6.currentPreference)("data-testid", "theme-option-" + option_r7.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](4, 7, option_r7.labelKey));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](7, 9, option_r7.descriptionKey));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", option_r7.value === ctx_r6.currentPreference);
  }
}
function HeaderComponent_div_22_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceHTML"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](1, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, HeaderComponent_div_22_button_2_Template, 9, 11, "button", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("@dropdownAnimation", ctx_r5.themeMenuOpen ? "open" : "closed");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵattribute"]("aria-label", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](1, 3, "header.theme.menuLabel"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r5.themeOptions);
  }
}
const _c0 = function (a0) {
  return {
    mode: a0
  };
};
class HeaderComponent {
  constructor(themeService, elementRef, dropdownCoordinator) {
    this.themeService = themeService;
    this.elementRef = elementRef;
    this.dropdownCoordinator = dropdownCoordinator;
    this.isDarkMode = false;
    this.themeMenuOpen = false;
    this.currentPreference = 'system';
    this.dropdownId = 'theme-preference';
    this.themeOptions = [{
      value: 'light',
      labelKey: 'header.theme.options.light.label',
      descriptionKey: 'header.theme.options.light.description'
    }, {
      value: 'dark',
      labelKey: 'header.theme.options.dark.label',
      descriptionKey: 'header.theme.options.dark.description'
    }, {
      value: 'system',
      labelKey: 'header.theme.options.system.label',
      descriptionKey: 'header.theme.options.system.description'
    }];
    this.subscriptions = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subscription();
  }
  ngOnInit() {
    this.subscriptions.add(this.themeService.darkMode$.subscribe(isDark => this.isDarkMode = isDark));
    this.subscriptions.add(this.themeService.preference$.subscribe(preference => this.currentPreference = preference));
    this.subscriptions.add(this.dropdownCoordinator.openDropdown$.subscribe(openId => {
      this.themeMenuOpen = openId === this.dropdownId;
    }));
  }
  ngOnDestroy() {
    this.subscriptions.unsubscribe();
    this.dropdownCoordinator.close(this.dropdownId);
  }
  toggleThemeMenu() {
    this.dropdownCoordinator.toggle(this.dropdownId);
  }
  selectTheme(preference) {
    this.themeService.setPreference(preference);
    this.dropdownCoordinator.close(this.dropdownId);
  }
  getThemeLabelKey() {
    const option = this.themeOptions.find(themeOption => themeOption.value === this.currentPreference);
    return option?.labelKey ?? 'header.theme.options.system.label';
  }
  onDocumentClick(event) {
    if (!this.themeMenuOpen) {
      return;
    }
    if (!this.elementRef.nativeElement.contains(event.target)) {
      this.dropdownCoordinator.close(this.dropdownId);
    }
  }
  onEscape() {
    this.dropdownCoordinator.close(this.dropdownId);
  }
  static {
    this.ɵfac = function HeaderComponent_Factory(t) {
      return new (t || HeaderComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_theme_service__WEBPACK_IMPORTED_MODULE_1__.ThemeService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_4__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_dropdown_coordinator_service__WEBPACK_IMPORTED_MODULE_2__.DropdownCoordinatorService));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
      type: HeaderComponent,
      selectors: [["app-header"]],
      hostBindings: function HeaderComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function HeaderComponent_click_HostBindingHandler($event) {
            return ctx.onDocumentClick($event);
          }, false, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresolveDocument"])("keydown.escape", function HeaderComponent_keydown_escape_HostBindingHandler() {
            return ctx.onEscape();
          }, false, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresolveDocument"]);
        }
      },
      decls: 24,
      vars: 23,
      consts: [[1, "sticky", "top-0", "z-50", "w-full", "border-b", "border-brand-borderSubtle", "bg-brand-surface/95", "dark:bg-brand-darkSurface/95", "shadow-brand-soft", "backdrop-blur-md", "transition-colors", "duration-300"], [1, "mx-auto", "flex", "max-w-7xl", "items-center", "justify-between", "px-6", "py-4", "lg:px-12"], [1, "flex", "items-center"], ["src", "assets/images/landscape-light.svg", "alt", "Easy Locker", "width", "1991", "height", "1026", "class", "h-10 lg:h-12 w-auto transition-opacity duration-300", 4, "ngIf"], ["src", "assets/images/landscape-dark.svg", "alt", "Easy Locker", "width", "1991", "height", "1026", "class", "h-10 lg:h-12 w-auto transition-opacity duration-300", 4, "ngIf"], [1, "flex", "items-center", "space-x-3", "lg:space-x-6"], [1, "header-picker"], ["type", "button", "aria-haspopup", "listbox", "data-testid", "theme-toggle", 1, "easy-pill-btn", "header-picker-btn", "theme-toggle-btn", "easy-focus-reset", "easy-focus-ring", 3, "click"], [1, "sr-only"], [3, "ngSwitch"], ["class", "theme-toggle-icon", "fill", "none", "stroke", "currentColor", "viewBox", "0 0 24 24", "aria-hidden", "true", 4, "ngSwitchCase"], ["class", "theme-toggle-icon", "fill", "none", "stroke", "currentColor", "viewBox", "0 0 24 24", "aria-hidden", "true", 4, "ngSwitchDefault"], [1, "header-picker-label", "theme-toggle-label", "hidden", "md:inline-flex"], ["fill", "none", "stroke", "currentColor", "viewBox", "0 0 24 24", "aria-hidden", "true", 1, "header-picker-chevron"], ["stroke-linecap", "round", "stroke-linejoin", "round", "stroke-width", "2", "d", "M19 9l-7 7-7-7"], ["class", "header-picker-menu", "role", "listbox", "data-testid", "theme-menu", 4, "ngIf"], ["src", "assets/images/landscape-light.svg", "alt", "Easy Locker", "width", "1991", "height", "1026", 1, "h-10", "lg:h-12", "w-auto", "transition-opacity", "duration-300"], ["src", "assets/images/landscape-dark.svg", "alt", "Easy Locker", "width", "1991", "height", "1026", 1, "h-10", "lg:h-12", "w-auto", "transition-opacity", "duration-300"], ["fill", "none", "stroke", "currentColor", "viewBox", "0 0 24 24", "aria-hidden", "true", 1, "theme-toggle-icon"], ["stroke-linecap", "round", "stroke-linejoin", "round", "stroke-width", "2", "d", "M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 0 018 0z"], ["stroke-linecap", "round", "stroke-linejoin", "round", "stroke-width", "2", "d", "M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"], ["stroke-linecap", "round", "stroke-linejoin", "round", "stroke-width", "2", "d", "M12 3c.132 0 .263.003.394.01a7 7 0 017.596 7.596A8 8 0 1112 3z"], ["stroke-linecap", "round", "stroke-linejoin", "round", "stroke-width", "2", "d", "M12 5v2m0 10v2m7-7h-2M7 12H5m12.071 5.071l-1.414-1.414M8.343 8.343L6.929 6.929m0 10.142l1.414-1.414m9.314-9.314l1.414-1.414"], ["role", "listbox", "data-testid", "theme-menu", 1, "header-picker-menu"], ["type", "button", "class", "header-picker-option easy-focus-reset easy-focus-ring", "role", "option", 3, "header-picker-option--active", "click", 4, "ngFor", "ngForOf"], ["type", "button", "role", "option", 1, "header-picker-option", "easy-focus-reset", "easy-focus-ring", 3, "click"], [1, "flex", "flex-col", "text-left"], [1, "text-sm", "font-semibold"], [1, "text-xs", "text-brand-textMuted"], ["class", "header-picker-indicator", "aria-hidden", "true", 4, "ngIf"], ["aria-hidden", "true", 1, "header-picker-indicator"]],
      template: function HeaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "header", 0)(1, "div", 1)(2, "div", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](3, HeaderComponent_img_3_Template, 1, 0, "img", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, HeaderComponent_img_4_Template, 1, 0, "img", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 5)(6, "div", 6)(7, "button", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function HeaderComponent_Template_button_click_7_listener() {
            return ctx.toggleThemeMenu();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](8, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](9, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "span", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](12, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](13, 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](14, HeaderComponent__svg_svg_14_Template, 2, 0, "svg", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](15, HeaderComponent__svg_svg_15_Template, 2, 0, "svg", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](16, HeaderComponent__svg_svg_16_Template, 3, 0, "svg", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "span", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](19, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceSVG"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "svg", 13);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](21, "path", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](22, HeaderComponent_div_22_Template, 3, 5, "div", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnamespaceHTML"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](23, "app-language-switcher");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.isDarkMode);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.isDarkMode);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵattribute"]("aria-expanded", ctx.themeMenuOpen)("aria-label", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](8, 12, "header.theme.buttonAria", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](21, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](9, 15, ctx.getThemeLabelKey()))));
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](12, 17, "header.theme.srLabel"));
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngSwitch", ctx.currentPreference);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngSwitchCase", "light");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngSwitchCase", "dark");
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](19, 19, ctx.getThemeLabelKey()));
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("rotate-180", ctx.themeMenuOpen);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.themeMenuOpen);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgSwitch, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgSwitchCase, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgSwitchDefault, _language_switcher_language_switcher_component__WEBPACK_IMPORTED_MODULE_3__.LanguageSwitcherComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__.TranslatePipe],
      styles: [".theme-toggle-icon[_ngcontent-%COMP%] {\n  height: 1.25rem;\n  width: 1.25rem;\n  color: currentColor\n}\n\n.theme-toggle-label[_ngcontent-%COMP%] {\n  font-size: 0.75rem;\n  line-height: 1rem;\n  font-weight: 600;\n  letter-spacing: 0.1em\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlci5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQUEsZUFBYztFQUFkLGNBQWM7RUFDZDtBQURjOztBQUtkO0VBQUEsa0JBQTRDO0VBQTVDLGlCQUE0QztFQUE1QyxnQkFBNEM7RUFBNUM7QUFBNEMiLCJmaWxlIjoiaGVhZGVyLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGhlbWUtdG9nZ2xlLWljb24ge1xuICBAYXBwbHkgaC01IHctNTtcbiAgY29sb3I6IGN1cnJlbnRDb2xvcjtcbn1cblxuLnRoZW1lLXRvZ2dsZS1sYWJlbCB7XG4gIEBhcHBseSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctd2lkZXN0O1xufVxuIl19 */\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy9oZWFkZXIvaGVhZGVyLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFBQSxlQUFjO0VBQWQsY0FBYztFQUNkO0FBRGM7O0FBS2Q7RUFBQSxrQkFBNEM7RUFBNUMsaUJBQTRDO0VBQTVDLGdCQUE0QztFQUE1QztBQUE0Qzs7QUFPOUMsb2hCQUFvaEIiLCJzb3VyY2VzQ29udGVudCI6WyIudGhlbWUtdG9nZ2xlLWljb24ge1xuICBAYXBwbHkgaC01IHctNTtcbiAgY29sb3I6IGN1cnJlbnRDb2xvcjtcbn1cblxuLnRoZW1lLXRvZ2dsZS1sYWJlbCB7XG4gIEBhcHBseSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctd2lkZXN0O1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
      data: {
        animation: [_animations_dropdown_animation__WEBPACK_IMPORTED_MODULE_0__.dropdownAnimation]
      }
    });
  }
}

/***/ }),

/***/ 9307:
/*!***************************************************!*\
  !*** ./src/app/components/hero/hero.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HeroComponent: () => (/* binding */ HeroComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ 852);
/* harmony import */ var _core_analytics_analytics_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core/analytics/analytics.service */ 7854);



class HeroComponent {
  constructor(translate, analytics) {
    this.translate = translate;
    this.analytics = analytics;
  }
  onReserve() {
    this.analytics.trackEvent('hero_click_book_now', {
      position: 'hero',
      cta_variant: 'primary'
    });
    this.translate.get('hero.links.reserve').subscribe(link => {
      window.open(link, '_blank');
    });
  }
  onDirections() {
    this.analytics.trackEvent('hero_click_get_directions', {
      position: 'hero',
      destination: 'google_maps'
    });
    this.translate.get('hero.links.maps').subscribe(link => {
      window.open(link, '_blank');
    });
  }
  static {
    this.ɵfac = function HeroComponent_Factory(t) {
      return new (t || HeroComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_core_analytics_analytics_service__WEBPACK_IMPORTED_MODULE_0__.AnalyticsService));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: HeroComponent,
      selectors: [["app-hero"]],
      decls: 22,
      vars: 15,
      consts: [[1, "relative", "flex", "flex-col", "items-center", "justify-center", "bg-gradient-to-br", "from-brand-infoBackground", "via-brand-surface", "to-brand-successBackground", "py-20", "md:py-24", "lg:py-28", "text-center", "text-brand-textPrimary", "font-sans", "overflow-hidden", "transition-colors", "duration-300"], [1, "absolute", "inset-0", "bg-grid-pattern", "opacity-5"], [1, "absolute", "top-10", "left-10", "w-72", "h-72", "bg-brand-accentPrimary/10", "rounded-full", "blur-3xl"], [1, "absolute", "bottom-10", "right-10", "w-96", "h-96", "bg-brand-accentSecondary/10", "rounded-full", "blur-3xl"], [1, "container", "mx-auto", "px-6", "lg:px-8", "relative", "z-10"], [1, "max-w-4xl", "mx-auto"], [1, "easy-hero-meta", "text-xs", "md:text-sm", "text-brand-textMuted", "tracking-[0.18em]", "uppercase", "mb-3", "md:mb-4"], ["data-testid", "hero-heading", 1, "easy-hero-title", "hero-title", "tracking-tight", "text-[2.1rem]", "md:text-6xl", "lg:text-7xl", "leading-[1.1]", "md:leading-tight", "text-brand-textPrimary", "dark:text-brand-darkTextStrong"], [1, "easy-hero-subtitle", "hero-subtitle", "max-w-3xl", "mx-auto"], [1, "easy-hero-cta-group", "md:flex-row", "md:justify-center", "md:items-center", "md:gap-6", "md:max-w-2xl"], ["data-testid", "hero-cta-reserve", 1, "easy-pill-btn", "easy-cta-primary", "w-full", "min-w-[280px]", "md:w-auto", 3, "click"], ["data-testid", "hero-cta-directions", 1, "easy-pill-btn", "easy-cta-secondary", "w-full", "min-w-[280px]", "md:w-auto", 3, "click"]],
      template: function HeroComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "section", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "div", 1)(2, "div", 2)(3, "div", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "div", 4)(5, "div", 5)(6, "p", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](8, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "h1", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](11, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "p", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](14, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "div", 9)(16, "button", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function HeroComponent_Template_button_click_16_listener() {
            return ctx.onReserve();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](17);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](18, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](19, "button", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function HeroComponent_Template_button_click_19_listener() {
            return ctx.onDirections();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](20);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](21, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](8, 5, "hero.availability"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](11, 7, "h1"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](14, 9, "home.description"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](18, 11, "hero.buttons.reserve"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](21, 13, "hero.buttons.directions"), " ");
        }
      },
      dependencies: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslatePipe],
      styles: [".easy-hero-meta[_ngcontent-%COMP%] {\n  font-weight: 600;\n  letter-spacing: 0.18em;\n  text-transform: uppercase;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlcm8uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFnQjtFQUNoQixzQkFBc0I7RUFDdEIseUJBQXlCO0FBQzNCIiwiZmlsZSI6Imhlcm8uY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5lYXN5LWhlcm8tbWV0YSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGxldHRlci1zcGFjaW5nOiAwLjE4ZW07XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG59XG4iXX0= */\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy9oZXJvL2hlcm8uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFnQjtFQUNoQixzQkFBc0I7RUFDdEIseUJBQXlCO0FBQzNCOztBQUVBLDRaQUE0WiIsInNvdXJjZXNDb250ZW50IjpbIi5lYXN5LWhlcm8tbWV0YSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGxldHRlci1zcGFjaW5nOiAwLjE4ZW07XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
    });
  }
}

/***/ }),

/***/ 5457:
/*!*****************************************************************************!*\
  !*** ./src/app/components/language-switcher/language-switcher.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LanguageSwitcherComponent: () => (/* binding */ LanguageSwitcherComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 2510);
/* harmony import */ var _animations_dropdown_animation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../animations/dropdown.animation */ 8439);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _services_language_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/language.service */ 8756);
/* harmony import */ var _services_dropdown_coordinator_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/dropdown-coordinator.service */ 3636);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ 852);







function LanguageSwitcherComponent_div_9_button_2_span_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "span", 11);
  }
}
function LanguageSwitcherComponent_div_9_button_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function LanguageSwitcherComponent_div_9_button_2_Template_button_click_0_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r5);
      const lang_r2 = restoredCtx.$implicit;
      const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r4.changeLanguage(lang_r2.code));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "span", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](4, LanguageSwitcherComponent_div_9_button_2_span_4_Template, 1, 0, "span", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const lang_r2 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("header-picker-option--active", lang_r2.code === ctx_r1.currentLanguage);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵattribute"]("aria-selected", lang_r2.code === ctx_r1.currentLanguage)("data-testid", "language-option-" + lang_r2.code);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](3, 6, lang_r2.labelKey));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", lang_r2.code === ctx_r1.currentLanguage);
  }
}
function LanguageSwitcherComponent_div_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnamespaceHTML"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](1, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](2, LanguageSwitcherComponent_div_9_button_2_Template, 5, 8, "button", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("@dropdownAnimation", ctx_r0.open ? "open" : "closed");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵattribute"]("aria-label", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](1, 3, "header.language.menuLabel"));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx_r0.languages);
  }
}
const _c0 = function (a0) {
  return {
    language: a0
  };
};
class LanguageSwitcherComponent {
  constructor(languageService, elementRef, dropdownCoordinator) {
    this.languageService = languageService;
    this.elementRef = elementRef;
    this.dropdownCoordinator = dropdownCoordinator;
    this.open = false;
    this.currentLanguage = 'en';
    this.dropdownId = 'language-selector';
    this.subscriptions = new rxjs__WEBPACK_IMPORTED_MODULE_4__.Subscription();
    this.languages = this.languageService.getSupportedLanguages();
  }
  ngOnInit() {
    this.subscriptions.add(this.languageService.language$.subscribe(lang => this.currentLanguage = lang));
    this.subscriptions.add(this.dropdownCoordinator.openDropdown$.subscribe(openId => {
      this.open = openId === this.dropdownId;
    }));
  }
  ngOnDestroy() {
    this.subscriptions.unsubscribe();
    this.dropdownCoordinator.close(this.dropdownId);
  }
  toggleDropdown() {
    this.dropdownCoordinator.toggle(this.dropdownId);
  }
  changeLanguage(langCode) {
    if (this.currentLanguage === langCode) {
      this.dropdownCoordinator.close(this.dropdownId);
      return;
    }
    this.languageService.setLanguage(langCode);
    this.dropdownCoordinator.close(this.dropdownId);
  }
  getCurrentLanguageLabelKey() {
    const lang = this.languages.find(l => l.code === this.currentLanguage);
    return lang?.labelKey ?? 'header.language.options.unknown';
  }
  onDocumentClick(event) {
    if (!this.open) {
      return;
    }
    const target = event.target;
    if (!this.elementRef.nativeElement.contains(target)) {
      this.dropdownCoordinator.close(this.dropdownId);
    }
  }
  onEscape() {
    this.dropdownCoordinator.close(this.dropdownId);
  }
  static {
    this.ɵfac = function LanguageSwitcherComponent_Factory(t) {
      return new (t || LanguageSwitcherComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_language_service__WEBPACK_IMPORTED_MODULE_1__.LanguageService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_3__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_dropdown_coordinator_service__WEBPACK_IMPORTED_MODULE_2__.DropdownCoordinatorService));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
      type: LanguageSwitcherComponent,
      selectors: [["app-language-switcher"]],
      hostBindings: function LanguageSwitcherComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function LanguageSwitcherComponent_click_HostBindingHandler($event) {
            return ctx.onDocumentClick($event);
          }, false, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresolveDocument"])("keydown.escape", function LanguageSwitcherComponent_keydown_escape_HostBindingHandler() {
            return ctx.onEscape();
          }, false, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresolveDocument"]);
        }
      },
      decls: 10,
      vars: 15,
      consts: [[1, "language-switcher", "header-picker"], ["type", "button", "aria-haspopup", "listbox", "data-testid", "language-switcher-toggle", 1, "easy-pill-btn", "header-picker-btn", "easy-focus-reset", "easy-focus-ring", 3, "click"], [1, "header-picker-label", "language-switcher-label"], ["fill", "none", "stroke", "currentColor", "viewBox", "0 0 24 24", "aria-hidden", "true", 1, "header-picker-chevron", "language-switcher-arrow"], ["stroke-linecap", "round", "stroke-linejoin", "round", "stroke-width", "2", "d", "M19 9l-7 7-7-7"], ["class", "header-picker-menu language-switcher-panel", "role", "listbox", "data-testid", "language-switcher-menu", 4, "ngIf"], ["role", "listbox", "data-testid", "language-switcher-menu", 1, "header-picker-menu", "language-switcher-panel"], ["type", "button", "class", "header-picker-option easy-focus-reset easy-focus-ring language-option", "role", "option", 3, "header-picker-option--active", "click", 4, "ngFor", "ngForOf"], ["type", "button", "role", "option", 1, "header-picker-option", "easy-focus-reset", "easy-focus-ring", "language-option", 3, "click"], [1, "language-option-label"], ["class", "header-picker-indicator", "aria-hidden", "true", 4, "ngIf"], ["aria-hidden", "true", 1, "header-picker-indicator"]],
      template: function LanguageSwitcherComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "button", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function LanguageSwitcherComponent_Template_button_click_1_listener() {
            return ctx.toggleDropdown();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](3, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "span", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](6, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnamespaceSVG"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "svg", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](8, "path", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](9, LanguageSwitcherComponent_div_9_Template, 3, 5, "div", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵattribute"]("aria-expanded", ctx.open)("aria-label", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](2, 6, "header.language.buttonAria", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](13, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](3, 9, ctx.getCurrentLanguageLabelKey()))));
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](6, 11, ctx.getCurrentLanguageLabelKey()), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("rotate-180", ctx.open);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.open);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__.TranslatePipe],
      styles: [".language-switcher[_ngcontent-%COMP%] {\n  display: inline-flex;\n  min-width: 6rem;\n}\n\n.language-switcher-label[_ngcontent-%COMP%] {\n  flex: 1 1 0%;\n  text-align: left;\n}\n\n.language-option-label[_ngcontent-%COMP%] {\n  font-size: 0.875rem;\n  line-height: 1.25rem;\n  font-weight: 600;\n}\n\n.language-option[_ngcontent-%COMP%] {\n  letter-spacing: 0.08em;\n  text-transform: none;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxhbmd1YWdlLXN3aXRjaGVyLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFBQSxvQkFBa0I7RUFDbEI7QUFEa0I7O0FBS2xCO0VBQUEsWUFBdUI7RUFBdkI7QUFBdUI7O0FBSXZCO0VBQUEsbUJBQTRCO0VBQTVCLG9CQUE0QjtFQUE1QjtBQUE0Qjs7QUFHOUI7RUFDRSxzQkFBc0I7RUFDdEIsb0JBQW9CO0FBQ3RCIiwiZmlsZSI6Imxhbmd1YWdlLXN3aXRjaGVyLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubGFuZ3VhZ2Utc3dpdGNoZXIge1xuICBAYXBwbHkgaW5saW5lLWZsZXg7XG4gIG1pbi13aWR0aDogNnJlbTtcbn1cblxuLmxhbmd1YWdlLXN3aXRjaGVyLWxhYmVsIHtcbiAgQGFwcGx5IGZsZXgtMSB0ZXh0LWxlZnQ7XG59XG5cbi5sYW5ndWFnZS1vcHRpb24tbGFiZWwge1xuICBAYXBwbHkgdGV4dC1zbSBmb250LXNlbWlib2xkO1xufVxuXG4ubGFuZ3VhZ2Utb3B0aW9uIHtcbiAgbGV0dGVyLXNwYWNpbmc6IDAuMDhlbTtcbiAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG59XG4iXX0= */\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy9sYW5ndWFnZS1zd2l0Y2hlci9sYW5ndWFnZS1zd2l0Y2hlci5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQUEsb0JBQWtCO0VBQ2xCLGVBQUE7QUFEa0I7O0FBS2xCO0VBQUEsWUFBdUI7RUFBdkIsZ0JBQUE7QUFBdUI7O0FBSXZCO0VBQUEsbUJBQTRCO0VBQTVCLG9CQUE0QjtFQUE1QixnQkFBQTtBQUE0Qjs7QUFHOUI7RUFDRSxzQkFBc0I7RUFDdEIsb0JBQW9CO0FBQ3RCOztBQUtBLDR4QkFBNHhCIiwic291cmNlc0NvbnRlbnQiOlsiLmxhbmd1YWdlLXN3aXRjaGVyIHtcbiAgQGFwcGx5IGlubGluZS1mbGV4O1xuICBtaW4td2lkdGg6IDZyZW07XG59XG5cbi5sYW5ndWFnZS1zd2l0Y2hlci1sYWJlbCB7XG4gIEBhcHBseSBmbGV4LTEgdGV4dC1sZWZ0O1xufVxuXG4ubGFuZ3VhZ2Utb3B0aW9uLWxhYmVsIHtcbiAgQGFwcGx5IHRleHQtc20gZm9udC1zZW1pYm9sZDtcbn1cblxuLmxhbmd1YWdlLW9wdGlvbiB7XG4gIGxldHRlci1zcGFjaW5nOiAwLjA4ZW07XG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ== */"],
      data: {
        animation: [_animations_dropdown_animation__WEBPACK_IMPORTED_MODULE_0__.dropdownAnimation]
      }
    });
  }
}

/***/ }),

/***/ 2185:
/*!*********************************************************!*\
  !*** ./src/app/components/pricing/pricing.component.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PricingComponent: () => (/* binding */ PricingComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _core_analytics_analytics_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core/analytics/analytics.service */ 7854);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ 852);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _shared_components_easy_card_easy_card_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/components/easy-card/easy-card.component */ 3277);





function PricingComponent_li_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "li", 8)(1, "app-easy-card", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function PricingComponent_li_11_Template_app_easy_card_click_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r3);
      const plan_r1 = restoredCtx.$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r2.onPlanClick(plan_r1));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "article", 10)(5, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](6, "img", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "div", 13)(9, "h3", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](11, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "p", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](14, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](15, "p", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](17, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "p", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](20, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const plan_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("interactive", true)("href", plan_r1.link || "#")("ariaLabel", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](2, 11, "hero.buttons.reserve") + " " + _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](3, 13, plan_r1.nameKey));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("src", plan_r1.image, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"])("alt", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](7, 15, plan_r1.nameKey));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵattribute"]("width", plan_r1.width)("height", plan_r1.height);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](11, 17, plan_r1.nameKey), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](14, 19, plan_r1.priceKey), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](17, 21, plan_r1.dimensionsKey), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](20, 23, plan_r1.descriptionKey), " ");
  }
}
class PricingComponent {
  constructor(analytics, elementRef, translate) {
    this.analytics = analytics;
    this.elementRef = elementRef;
    this.translate = translate;
    this.hasLoggedView = false;
    this.bookingLink = '';
    this.plans = [{
      id: 'M',
      image: 'assets/images/box-type-m.png',
      nameKey: 'lockerSizes.plans.m.name',
      priceKey: 'lockerSizes.plans.m.price',
      dimensionsKey: 'lockerSizes.plans.m.dimensions',
      descriptionKey: 'lockerSizes.plans.m.description',
      sizeCm: '28x41x56',
      width: 360,
      height: 360
    }, {
      id: 'L',
      image: 'assets/images/box-type-l.png',
      nameKey: 'lockerSizes.plans.l.name',
      priceKey: 'lockerSizes.plans.l.price',
      dimensionsKey: 'lockerSizes.plans.l.dimensions',
      descriptionKey: 'lockerSizes.plans.l.description',
      sizeCm: '50x41x56',
      width: 360,
      height: 360
    }, {
      id: 'XL',
      image: 'assets/images/box-type-xl.png',
      nameKey: 'lockerSizes.plans.xl.name',
      priceKey: 'lockerSizes.plans.xl.price',
      dimensionsKey: 'lockerSizes.plans.xl.dimensions',
      descriptionKey: 'lockerSizes.plans.xl.description',
      sizeCm: '82x41x56',
      width: 287,
      height: 360
    }];
  }
  ngOnInit() {
    this.translate.get('hero.links.reserve').subscribe(link => {
      const trimmed = link?.trim() ?? '';
      this.bookingLink = trimmed;
      this.plans = this.plans.map(plan => ({
        ...plan,
        link: trimmed
      }));
    });
  }
  ngAfterViewInit() {
    this.observePlansSection();
  }
  ngOnDestroy() {
    this.plansObserver?.disconnect();
  }
  onPlanSelected(plan) {
    const planName = this.translate.instant(plan.nameKey);
    const payload = {
      plan_id: plan.id,
      plan_name: planName,
      plan_size_cm: plan.sizeCm,
      source: 'pricing_section',
      cta_variant: 'plan_card_cta'
    };
    this.analytics.trackEvent('plan_card_click', payload);
    // navigation handled by anchor element in template
  }

  onPlanClick(plan) {
    this.onPlanSelected(plan);
  }
  observePlansSection() {
    if (typeof window === 'undefined') {
      return;
    }
    if (!('IntersectionObserver' in window)) {
      this.logPlansView('scroll');
      return;
    }
    this.plansObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          this.logPlansView('scroll');
        }
      });
    }, {
      threshold: 0.35
    });
    this.plansObserver.observe(this.elementRef.nativeElement);
  }
  logPlansView(method) {
    if (this.hasLoggedView) {
      return;
    }
    this.hasLoggedView = true;
    this.analytics.trackEvent('plans_view', {
      method
    });
    this.plansObserver?.disconnect();
  }
  static {
    this.ɵfac = function PricingComponent_Factory(t) {
      return new (t || PricingComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_core_analytics_analytics_service__WEBPACK_IMPORTED_MODULE_0__.AnalyticsService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslateService));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
      type: PricingComponent,
      selectors: [["app-pricing"]],
      decls: 12,
      vars: 7,
      consts: [[1, "py-16", "lg:py-24", "text-brand-textPrimary", "font-sans", "transition-colors", "duration-300"], [1, "container", "mx-auto", "px-6", "lg:px-8"], [1, "section-heading", "text-center", "mb-10", "md:mb-12", "max-w-3xl", "mx-auto"], [1, "text-3xl", "md:text-4xl", "lg:text-5xl", "font-bold", "text-brand-textPrimary", "text-center", "dark:text-brand-darkTextStrong"], [1, "mt-2", "text-base", "md:text-lg", "text-brand-textSecondary", "text-center", "max-w-xl", "mx-auto"], [1, "easy-section-underline"], [1, "grid", "grid-cols-1", "md:grid-cols-3", "gap-8", "max-w-7xl", "mx-auto"], ["class", "h-full", 4, "ngFor", "ngForOf"], [1, "h-full"], ["as", "a", "align", "center", "paddingClass", "p-6", "target", "_blank", "rel", "noopener noreferrer", 1, "h-full", 3, "interactive", "href", "ariaLabel", "click"], [1, "flex", "h-full", "flex-col", "gap-4", "text-center"], [1, "flex", "justify-center"], ["loading", "lazy", 1, "h-48", "w-auto", "object-contain", 3, "src", "alt"], [1, "flex", "flex-col", "gap-3"], [1, "text-2xl", "font-semibold", "text-brand-textPrimary"], [1, "text-brand-accentPrimary", "text-xl", "font-semibold"], [1, "text-brand-textMuted", "text-sm", "uppercase", "tracking-[0.2em]"], [1, "text-brand-textSecondary"]],
      template: function PricingComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "header", 2)(3, "h2", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](5, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "p", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](8, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](9, "div", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](10, "ul", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](11, PricingComponent_li_11_Template, 21, 25, "li", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](5, 3, "lockerSizes.title"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind1"](8, 5, "lockerSizes.subtitle"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.plans);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgForOf, _shared_components_easy_card_easy_card_component__WEBPACK_IMPORTED_MODULE_1__.EasyCardComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslatePipe],
      styles: ["/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcmljaW5nLmNvbXBvbmVudC5jc3MifQ== */\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy9wcmljaW5nL3ByaWNpbmcuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQ0Esb0tBQW9LIiwic291cmNlUm9vdCI6IiJ9 */"]
    });
  }
}

/***/ }),

/***/ 5375:
/*!*******************************************************************!*\
  !*** ./src/app/components/testimonials/testimonials.component.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TestimonialsComponent: () => (/* binding */ TestimonialsComponent)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 6443);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 1318);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 9452);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _core_analytics_analytics_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core/analytics/analytics.service */ 7854);
/* harmony import */ var _services_language_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/language.service */ 8756);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _shared_components_easy_card_easy_card_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/components/easy-card/easy-card.component */ 3277);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ 852);









function TestimonialsComponent_div_11_div_14_div_3_span_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "span", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, "\u2605");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}
const _c0 = function (a0) {
  return {
    rating: a0
  };
};
function TestimonialsComponent_div_11_div_14_div_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](1, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](2, TestimonialsComponent_div_11_div_14_div_3_span_2_Template, 2, 0, "span", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const review_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵattribute"]("aria-label", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](1, 2, "testimonials_rating_aria", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](5, _c0, review_r7.rating || 0)));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx_r8.getStars(review_r7.rating));
  }
}
function TestimonialsComponent_div_11_div_14_small_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "small", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const review_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](review_r7.date);
  }
}
function TestimonialsComponent_div_11_div_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 22)(1, "app-easy-card", 23)(2, "article", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](3, TestimonialsComponent_div_11_div_14_div_3_Template, 3, 7, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "p", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "div", 27)(7, "span", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](9, TestimonialsComponent_div_11_div_14_small_9_Template, 2, 1, "small", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const review_r7 = ctx.$implicit;
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵstyleProp"]("width", ctx_r6.slideWidthPercentage, "%");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("interactive", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r6.getStars(review_r7.rating).length);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", review_r7.text, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", review_r7.author, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", review_r7.date);
  }
}
function TestimonialsComponent_div_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 6)(1, "div", 12)(2, "button", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function TestimonialsComponent_div_11_Template_button_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r15);
      const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r14.onPrevClick());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4, "Anterior");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "svg", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](6, "path", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnamespaceHTML"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function TestimonialsComponent_div_11_Template_button_click_7_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r15);
      const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r16.onNextClick());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9, "Siguiente");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "svg", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](11, "path", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnamespaceHTML"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](12, "div", 19)(13, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("transitionend", function TestimonialsComponent_div_11_Template_div_transitionend_13_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r15);
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r17.onTrackTransitionEnd());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](14, TestimonialsComponent_div_11_div_14_Template, 10, 7, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("opacity-50", !ctx_r0.canNavigate)("pointer-events-none", !ctx_r0.canNavigate);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", !ctx_r0.canNavigate);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("opacity-50", !ctx_r0.canNavigate)("pointer-events-none", !ctx_r0.canNavigate);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", !ctx_r0.canNavigate);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵstyleProp"]("transform", ctx_r0.sliderTransform)("will-change", "transform")("transition-duration", ctx_r0.trackTransitionDuration);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx_r0.carouselReviews)("ngForTrackBy", ctx_r0.trackByAuthor);
  }
}
function TestimonialsComponent_ng_template_12_div_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 36)(1, "p", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](3, 1, "testimonials_placeholder_loading"), " ");
  }
}
function TestimonialsComponent_ng_template_12_section_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r21 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "section", 38)(1, "div", 39)(2, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnamespaceSVG"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "svg", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](4, "path", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnamespaceHTML"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "h3", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](7, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "p", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](10, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "div", 45)(12, "a", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function TestimonialsComponent_ng_template_12_section_1_Template_a_click_12_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r21);
      const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r20.onLeaveReviewClick());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](13, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](15, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "a", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function TestimonialsComponent_ng_template_12_section_1_Template_a_click_16_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r21);
      const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r22.onViewProfileClick());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](17, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](18);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](19, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](20, "p", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](22, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](7, 9, "testimonials_empty_title"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](10, 11, "testimonials_empty_body"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("href", ctx_r19.reviewUrl, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵattribute"]("aria-label", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](13, 13, "testimonials_button_review_aria"));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](15, 15, "testimonials_button_review"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("href", ctx_r19.profileUrl, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵattribute"]("aria-label", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](17, 17, "testimonials_button_profile_aria"));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](19, 19, "testimonials_button_profile"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](22, 21, "testimonials_empty_trust"), " ");
  }
}
function TestimonialsComponent_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, TestimonialsComponent_ng_template_12_div_0_Template, 4, 3, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, TestimonialsComponent_ng_template_12_section_1_Template, 23, 23, "section", 35);
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r2.isLoading);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx_r2.isLoading);
  }
}
function TestimonialsComponent_p_14_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "p", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, ctx_r3.summaryTranslationKey), " ");
  }
}
function TestimonialsComponent_p_15_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "p", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx_r4.lastUpdatedDisplay, " ");
  }
}
function TestimonialsComponent_div_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 51)(1, "a", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function TestimonialsComponent_div_16_Template_a_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r24);
      const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r23.onViewProfileClick());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("href", ctx_r5.profileUrl, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵattribute"]("aria-label", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 3, "testimonials_button_all_reviews_aria"));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](4, 5, "testimonials_button_all_reviews"), " ");
  }
}
class TestimonialsComponent {
  constructor(http, analytics, elementRef, languageService) {
    this.http = http;
    this.analytics = analytics;
    this.elementRef = elementRef;
    this.languageService = languageService;
    this.maxReviews = 6;
    this.googleApiUrl = 'https://places.googleapis.com/v1/places';
    this.profileUrl = 'https://share.google/Mz0YZ1RFwkV0uToTK';
    this.reviewUrl = 'https://g.page/r/Cdlcmss1Q8AFEBM/review';
    this.desktopVisibleCount = 3;
    this.tabletVisibleCount = 2;
    this.mobileVisibleCount = 1;
    this.autoSlideMs = 5500;
    this.lastUpdatedCopy = {
      es: 'Última actualización',
      en: 'Last update',
      fr: 'Dernière mise à jour',
      de: 'Letzte Aktualisierung',
      it: 'Ultimo aggiornamento'
    };
    this.reviews = [];
    this.isLoading = true;
    this.hasLoggedView = false;
    this.sectionVisible = false;
    this.localizedReviews = [];
    this.currentIndex = 0;
    this.currentVisibleCount = this.desktopVisibleCount;
    this.transitionEnabled = true;
    this.carouselReviews = [];
  }
  ngOnInit() {
    this.languageSubscription = this.languageService.language$.subscribe(lang => this.applyLanguageToReviews(lang));
    this.loadCachedReviews();
  }
  ngAfterViewInit() {
    this.observeSection();
  }
  ngOnDestroy() {
    this.visibilityObserver?.disconnect();
    this.languageSubscription?.unsubscribe();
    this.stopAutoSlide();
  }
  onWindowResize() {
    if (!this.reviews.length) {
      return;
    }
    this.updateVisibleCount();
  }
  get hasReviews() {
    return this.reviews.length > 0;
  }
  get canNavigate() {
    return this.reviews.length > this.currentVisibleCount;
  }
  get trackTransitionDuration() {
    return this.transitionEnabled ? '500ms' : '0ms';
  }
  get summaryTranslationKey() {
    if (this.isLoading) {
      return 'testimonials_summary_loading';
    }
    return this.hasReviews ? 'testimonials_summary_verified' : 'testimonials_summary_empty';
  }
  getStars(count) {
    const safeCount = this.normalizeRating(count);
    return Array.from({
      length: safeCount
    });
  }
  trackByAuthor(index, review) {
    return `${index}-${review.author}-${review.date ?? ''}`;
  }
  onPrevClick() {
    if (!this.canNavigate) {
      return;
    }
    this.stopAutoSlide();
    this.prevSlide();
    this.startAutoSlide();
  }
  onNextClick() {
    if (!this.canNavigate) {
      return;
    }
    this.stopAutoSlide();
    this.nextSlide();
    this.startAutoSlide();
  }
  onTrackTransitionEnd() {
    if (!this.canNavigate) {
      return;
    }
    const buffer = Math.min(this.currentVisibleCount, this.reviews.length);
    const firstRealIndex = buffer;
    const lastRealIndex = buffer + this.reviews.length - 1;
    if (this.currentIndex > lastRealIndex) {
      this.jumpToIndex(firstRealIndex);
    } else if (this.currentIndex < firstRealIndex) {
      this.jumpToIndex(lastRealIndex);
    }
  }
  onLeaveReviewClick() {
    this.analytics.trackEvent('reviews_click_leave_review', {
      destination: 'google_reviews'
    });
  }
  onViewProfileClick() {
    this.analytics.trackEvent('reviews_click_view_profile', {
      destination: 'google_business_profile'
    });
  }
  loadCachedReviews() {
    this.http.get('assets/data/google-reviews.json', {
      headers: {
        'Cache-Control': 'no-store'
      },
      observe: 'response'
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(response => {
      this.cachedLastModified = response.headers.get('last-modified') ?? undefined;
      return response.body ?? [];
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.catchError)(() => (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.of)([]))).subscribe(cached => {
      this.localizedReviews = this.normalizeCachedReviews(cached);
      if (this.localizedReviews.length) {
        const lang = this.languageService.getCurrentLanguage();
        this.applyLanguageToReviews(lang);
        this.updateLastUpdatedLabel(lang);
        this.isLoading = false;
        this.maybeLogReviewsView();
        this.startAutoSlide();
      } else {
        this.fetchReviews();
      }
    });
  }
  fetchReviews() {
    const config = this.getGoogleReviewsConfig();
    if (!config) {
      console.warn('Testimonials section: missing Google Reviews configuration');
      this.isLoading = false;
      this.reviews = [];
      this.maybeLogReviewsView();
      return;
    }
    this.isLoading = true;
    const lang = this.languageService.getCurrentLanguage();
    const url = `${this.googleApiUrl}/${config.placeId}`;
    const params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpParams().set('fields', 'reviews').set('key', config.apiKey).set('languageCode', lang);
    this.http.get(url, {
      params,
      headers: {
        'Cache-Control': 'no-store'
      }
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(payload => this.normalizeGooglePayload(payload, lang)), (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.catchError)(error => {
      console.warn('Testimonials section: unable to fetch Google reviews', error);
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.of)([]);
    })).subscribe(reviews => {
      this.localizedReviews = reviews;
      this.applyLanguageToReviews(lang);
      this.cachedLastModified = new Date().toISOString();
      this.updateLastUpdatedLabel(lang);
      this.isLoading = false;
      this.maybeLogReviewsView();
      this.startAutoSlide();
    });
  }
  observeSection() {
    if (typeof window === 'undefined') {
      return;
    }
    if (!('IntersectionObserver' in window)) {
      this.sectionVisible = true;
      this.maybeLogReviewsView();
      return;
    }
    this.visibilityObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          this.sectionVisible = true;
          this.maybeLogReviewsView();
        }
      });
    }, {
      threshold: 0.35
    });
    this.visibilityObserver.observe(this.elementRef.nativeElement);
  }
  maybeLogReviewsView() {
    if (this.hasLoggedView || !this.sectionVisible || this.isLoading) {
      return;
    }
    this.hasLoggedView = true;
    this.analytics.trackEvent('reviews_view', {
      has_reviews: this.hasReviews
    });
    this.visibilityObserver?.disconnect();
  }
  getGoogleReviewsConfig() {
    const globalWindow = window;
    const apiKey = globalWindow?.EASY_LOCKER_GOOGLE_API_KEY?.trim();
    const placeId = globalWindow?.EASY_LOCKER_GOOGLE_PLACE_ID?.trim();
    if (apiKey && placeId) {
      return {
        apiKey,
        placeId
      };
    }
    return null;
  }
  normalizeGooglePayload(payload, lang) {
    if (!payload || payload.status === 'ZERO_RESULTS' || payload.status === 'NOT_FOUND') {
      return [];
    }
    const rawReviews = payload.reviews ?? [];
    return rawReviews.map(review => ({
      author: review.authorAttribution?.displayName?.trim() || 'Google user',
      rating: this.normalizeRating(review.rating),
      date: review.relativePublishTimeDescription || this.formatTimestamp(review.publishTime),
      original: {
        language: review.originalText?.languageCode || review.text?.languageCode || lang,
        text: review.originalText?.text?.trim() || review.text?.text?.trim() || ''
      },
      translations: {
        [lang]: review.text?.text?.trim() || review.originalText?.text?.trim() || ''
      }
    })).filter(review => !!review.translations[lang] && !!review.author).map(review => ({
      ...review,
      author: review.author.trim()
    })).slice(0, this.maxReviews);
  }
  normalizeCachedReviews(source) {
    if (!Array.isArray(source)) {
      return [];
    }
    return source.map((review, index) => ({
      author: review.author?.trim?.() || `cached-author-${index}`,
      rating: this.normalizeRating(review.rating),
      date: review.date,
      original: {
        language: review.original?.language,
        text: review.original?.text?.trim?.() || ''
      },
      translations: Object.fromEntries(Object.entries(review.translations || {}).map(([k, v]) => [k, v?.trim?.() || '']))
    })).filter(review => !!review.author).slice(0, this.maxReviews);
  }
  applyLanguageToReviews(lang) {
    if (!this.localizedReviews.length) {
      return;
    }
    this.reviews = this.localizedReviews.map(review => {
      const text = review.translations?.[lang] || review.translations?.[review.original?.language ?? ''] || review.original?.text || '';
      return {
        author: review.author,
        text: text,
        rating: review.rating,
        date: review.date
      };
    }).filter(review => !!review.text && !!review.author);
    this.rebuildCarousel();
    this.updateLastUpdatedLabel(lang);
  }
  get slideWidthPercentage() {
    return 100 / this.currentVisibleCount;
  }
  get sliderTransform() {
    const offset = this.currentIndex * this.slideWidthPercentage;
    return `translateX(-${offset}%)`;
  }
  prevSlide() {
    if (!this.canNavigate) {
      return;
    }
    this.transitionEnabled = true;
    this.currentIndex = this.currentIndex - 1;
  }
  nextSlide() {
    if (!this.canNavigate) {
      return;
    }
    this.transitionEnabled = true;
    this.currentIndex = this.currentIndex + 1;
  }
  startAutoSlide() {
    this.stopAutoSlide();
    if (!this.canNavigate) {
      return;
    }
    this.autoSlideTimer = setInterval(() => this.nextSlide(), this.autoSlideMs);
  }
  stopAutoSlide() {
    if (this.autoSlideTimer) {
      clearInterval(this.autoSlideTimer);
      this.autoSlideTimer = undefined;
    }
  }
  updateVisibleCount() {
    const width = typeof window !== 'undefined' ? window.innerWidth : 1440;
    const next = width < 768 ? this.mobileVisibleCount : width < 1024 ? this.tabletVisibleCount : this.desktopVisibleCount;
    if (next !== this.currentVisibleCount) {
      this.currentVisibleCount = next;
      this.rebuildCarousel();
    }
  }
  rebuildCarousel() {
    if (!this.reviews.length) {
      this.carouselReviews = [];
      this.currentIndex = 0;
      this.transitionEnabled = true;
      return;
    }
    if (!this.canNavigate) {
      this.carouselReviews = [...this.reviews];
      this.currentIndex = 0;
      this.transitionEnabled = true;
      this.stopAutoSlide();
      return;
    }
    const buffer = Math.min(this.currentVisibleCount, this.reviews.length);
    const head = this.reviews.slice(0, buffer);
    const tail = this.reviews.slice(-buffer);
    this.carouselReviews = [...tail, ...this.reviews, ...head];
    this.transitionEnabled = false;
    this.currentIndex = buffer;
    setTimeout(() => {
      this.transitionEnabled = true;
      this.startAutoSlide();
    }, 0);
  }
  jumpToIndex(index) {
    this.transitionEnabled = false;
    this.currentIndex = index;
    setTimeout(() => {
      this.transitionEnabled = true;
    }, 0);
  }
  normalizeRating(value) {
    if (value === undefined || value === null) {
      return 0;
    }
    const parsed = typeof value === 'string' ? parseFloat(value) : value;
    if (Number.isNaN(parsed)) {
      return 0;
    }
    return Math.max(0, Math.min(5, Math.round(parsed)));
  }
  formatTimestamp(timestamp) {
    if (!timestamp) {
      return undefined;
    }
    try {
      const date = typeof timestamp === 'number' ? new Date(timestamp * 1000) : new Date(timestamp);
      return new Intl.DateTimeFormat(undefined, {
        month: 'short',
        year: 'numeric'
      }).format(date);
    } catch (error) {
      console.warn('Testimonials section: unable to format review date', error);
      return undefined;
    }
  }
  updateLastUpdatedLabel(lang) {
    const formatted = this.formatLastUpdated(lang);
    this.lastUpdatedDisplay = formatted ? `${this.lastUpdatedCopy[lang] ?? this.lastUpdatedCopy['en']}: ${formatted}` : undefined;
  }
  formatLastUpdated(lang) {
    if (!this.cachedLastModified) {
      return undefined;
    }
    try {
      const parsed = new Date(this.cachedLastModified);
      if (Number.isNaN(parsed.getTime())) {
        return undefined;
      }
      return new Intl.DateTimeFormat(lang, {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      }).format(parsed);
    } catch (error) {
      console.warn('Testimonials section: unable to format last-updated date', error);
      return undefined;
    }
  }
  static {
    this.ɵfac = function TestimonialsComponent_Factory(t) {
      return new (t || TestimonialsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_core_analytics_analytics_service__WEBPACK_IMPORTED_MODULE_0__.AnalyticsService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_3__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_language_service__WEBPACK_IMPORTED_MODULE_1__.LanguageService));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
      type: TestimonialsComponent,
      selectors: [["app-testimonials"]],
      hostBindings: function TestimonialsComponent_HostBindings(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("resize", function TestimonialsComponent_resize_HostBindingHandler() {
            return ctx.onWindowResize();
          }, false, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresolveWindow"]);
        }
      },
      decls: 17,
      vars: 11,
      consts: [[1, "py-16", "lg:py-24", "text-brand-textPrimary", "transition-colors", "duration-300"], [1, "container", "mx-auto", "px-6", "lg:px-8"], [1, "section-heading", "text-center", "max-w-3xl", "mx-auto", "mb-12"], ["id", "easy-locker-testimonials-title", 1, "text-3xl", "md:text-4xl", "lg:text-5xl", "font-bold", "text-brand-textPrimary", "text-center", "dark:text-brand-darkTextStrong"], [1, "mt-2", "text-base", "md:text-lg", "text-brand-textSecondary", "text-center", "max-w-xl", "mx-auto"], [1, "easy-section-underline"], [1, "mt-10"], ["class", "mt-10", 4, "ngIf", "ngIfElse"], ["testimonialsFallback", ""], ["class", "mt-8 text-center text-sm text-brand-accentPrimary", 4, "ngIf"], ["class", "mt-2 text-center text-xs text-brand-textMuted", 4, "ngIf"], ["class", "mt-6 flex justify-center", 4, "ngIf"], [1, "relative", "max-w-6xl", "mx-auto"], ["type", "button", 1, "control-compact", "absolute", "-left-5", "md:-left-10", "top-1/2", "-translate-y-1/2", "z-10", 3, "disabled", "click"], [1, "sr-only"], ["viewBox", "0 0 24 24", "fill", "none", "stroke", "currentColor", "stroke-width", "2", "stroke-linecap", "round", "stroke-linejoin", "round", "aria-hidden", "true", 1, "h-4", "w-4"], ["d", "M15 18l-6-6 6-6"], ["type", "button", 1, "control-compact", "absolute", "-right-5", "md:-right-10", "top-1/2", "-translate-y-1/2", "z-10", 3, "disabled", "click"], ["d", "M9 6l6 6-6 6"], [1, "overflow-hidden", "carousel-viewport"], [1, "flex", "items-stretch", "transition-transform", "ease-out", 3, "transitionend"], ["class", "flex-none box-border px-3 lg:px-4", 3, "width", 4, "ngFor", "ngForOf", "ngForTrackBy"], [1, "flex-none", "box-border", "px-3", "lg:px-4"], ["as", "div", "align", "left", "paddingClass", "p-0", 3, "interactive"], [1, "testimonial-card", "flex", "flex-col", "gap-4", "p-6"], ["class", "flex items-center gap-1 text-brand-accentPrimary text-xl", "role", "img", 4, "ngIf"], [1, "text-sm", "text-brand-textSecondary", "leading-relaxed", "whitespace-pre-line", "break-words"], [1, "mt-2", "flex", "flex-col", "text-sm", "text-brand-textSecondary"], [1, "font-semibold", "text-brand-textPrimary", "truncate"], ["class", "truncate", 4, "ngIf"], ["role", "img", 1, "flex", "items-center", "gap-1", "text-brand-accentPrimary", "text-xl"], ["aria-hidden", "true", 4, "ngFor", "ngForOf"], ["aria-hidden", "true"], [1, "truncate"], ["class", "bg-brand-surface border border-dashed border-brand-border rounded-2xl px-6 py-16 text-center text-brand-textSecondary", 4, "ngIf"], ["class", "mt-8 md:mt-10", 4, "ngIf"], [1, "bg-brand-surface", "border", "border-dashed", "border-brand-border", "rounded-2xl", "px-6", "py-16", "text-center", "text-brand-textSecondary"], [1, "text-base"], [1, "mt-8", "md:mt-10"], [1, "max-w-3xl", "mx-auto", "px-5", "sm:px-8", "py-8", "rounded-3xl", "bg-brand-surface", "border", "border-brand-borderSubtle", "shadow-[var(--easy-shadow-elevated-soft)]"], [1, "w-10", "h-10", "mx-auto", "mb-3", "flex", "items-center", "justify-center", "rounded-full", "bg-brand-backgroundSoft/80", "text-brand-accentPrimary/90"], ["viewBox", "0 0 24 24", "fill", "currentColor", "aria-hidden", "true", 1, "w-5", "h-5"], ["d", "M9.5 11.75c0 3.72-1.92 6.5-5 6.5-.35 0-.5-.15-.5-.5 0-.17.03-.35.08-.52.3-1 .76-1.94 1.38-2.83.63-.9 1.36-1.74 2.2-2.53L7 12h-.5c-1.33 0-2-.5-2-1.5 0-1.36 1.03-2.5 3-2.5 1.7 0 2.75 1.04 2.75 3.75Zm11 0c0 3.72-1.92 6.5-5 6.5-.35 0-.5-.15-.5-.5 0-.17.03-.35.08-.52.3-1 .76-1.94 1.38-2.83.63-.9 1.36-1.74 2.2-2.53l-.15.13h-.5c-1.34 0-2-.5-2-1.5 0-1.36 1.03-2.5 3-2.5 1.7 0 2.75 1.04 2.75 3.75Z"], [1, "text-xl", "md:text-2xl", "font-semibold", "text-brand-textPrimary", "text-center"], [1, "mt-2", "text-base", "md:text-lg", "text-brand-textSecondary", "text-center", "max-w-xl", "mx-auto", "leading-relaxed"], [1, "mt-6", "flex", "flex-col", "sm:flex-row", "gap-4", "sm:gap-6", "justify-center", "items-center"], ["target", "_blank", "rel", "noopener noreferrer", 1, "easy-pill-btn", "easy-cta-primary", "w-full", "sm:w-auto", "justify-center", 3, "href", "click"], ["target", "_blank", "rel", "noopener noreferrer", 1, "easy-pill-btn", "easy-cta-secondary", "w-full", "sm:w-auto", "justify-center", 3, "href", "click"], [1, "mt-5", "text-xs", "md:text-sm", "text-brand-textMuted", "text-center", "max-w-3xl", "mx-auto", "leading-relaxed"], [1, "mt-8", "text-center", "text-sm", "text-brand-accentPrimary"], [1, "mt-2", "text-center", "text-xs", "text-brand-textMuted"], [1, "mt-6", "flex", "justify-center"], ["target", "_blank", "rel", "noopener noreferrer", 1, "easy-pill-btn", "easy-cta-secondary", "mx-auto", 3, "href", "click"]],
      template: function TestimonialsComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "section", 0)(1, "div", 1)(2, "header", 2)(3, "h2", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](5, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "p", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](8, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](9, "div", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](11, TestimonialsComponent_div_11_Template, 15, 18, "div", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](12, TestimonialsComponent_ng_template_12_Template, 2, 2, "ng-template", null, 8, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplateRefExtractor"]);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](14, TestimonialsComponent_p_14_Template, 3, 3, "p", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](15, TestimonialsComponent_p_15_Template, 2, 1, "p", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](16, TestimonialsComponent_div_16_Template, 5, 7, "div", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
        }
        if (rf & 2) {
          const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](13);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](5, 7, "sections.testimonials.title"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](8, 9, "sections.testimonials.subtitle"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.hasReviews)("ngIfElse", _r1);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.hasReviews);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.hasReviews && ctx.lastUpdatedDisplay);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.hasReviews);
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _shared_components_easy_card_easy_card_component__WEBPACK_IMPORTED_MODULE_2__.EasyCardComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__.TranslatePipe],
      styles: [".text-clamp-3[_ngcontent-%COMP%] {\n\tdisplay: -webkit-box;\n\t-webkit-line-clamp: 3;\n\t-webkit-box-orient: vertical;\n\toverflow: hidden;\n}\n\n.text-clamp-5[_ngcontent-%COMP%] {\n\tdisplay: -webkit-box;\n\t-webkit-line-clamp: 5;\n\t-webkit-box-orient: vertical;\n\toverflow: hidden;\n}\n\n.testimonial-card[_ngcontent-%COMP%] {\n\tbox-sizing: border-box;\n}\n\n.carousel-viewport[_ngcontent-%COMP%] {\n\tposition: relative;\n\t\n\n\tmask-image: linear-gradient(\n\t\tto right,\n\t\ttransparent 0%,\n\t\tblack 8%,\n\t\tblack 92%,\n\t\ttransparent 100%\n\t);\n}\n\n@supports not (mask-image: linear-gradient(to right, transparent, black)) {\n\t.carousel-viewport[_ngcontent-%COMP%]::before, .carousel-viewport[_ngcontent-%COMP%]::after {\n\t\tcontent: '';\n\t\tposition: absolute;\n\t\ttop: 0;\n\t\tbottom: 0;\n\t\twidth: 12%;\n\t\tpointer-events: none;\n\t\tz-index: 5;\n\t}\n\n\t.carousel-viewport[_ngcontent-%COMP%]::before {\n\t\tleft: 0;\n\t\tbackground: linear-gradient(\n\t\t\tto right,\n\t\t\tvar(--color-page-bg, #0f172a) 0%,\n\t\t\trgba(15, 23, 42, 0) 100%\n\t\t);\n\t}\n\n\t.carousel-viewport[_ngcontent-%COMP%]::after {\n\t\tright: 0;\n\t\tbackground: linear-gradient(\n\t\t\tto left,\n\t\t\tvar(--color-page-bg, #0f172a) 0%,\n\t\t\trgba(15, 23, 42, 0) 100%\n\t\t);\n\t}\n}\n\n\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRlc3RpbW9uaWFscy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFDQTtDQUNDLG9CQUFvQjtDQUNwQixxQkFBcUI7Q0FDckIsNEJBQTRCO0NBQzVCLGdCQUFnQjtBQUNqQjs7QUFFQTtDQUNDLG9CQUFvQjtDQUNwQixxQkFBcUI7Q0FDckIsNEJBQTRCO0NBQzVCLGdCQUFnQjtBQUNqQjs7QUFFQTtDQUNDLHNCQUFzQjtBQUN2Qjs7QUFFQTtDQUNDLGtCQUFrQjtDQUNsQixxREFBcUQ7Q0FRckQ7Ozs7OztFQU1DO0FBQ0Y7O0FBRUE7Q0FDQzs7RUFFQyxXQUFXO0VBQ1gsa0JBQWtCO0VBQ2xCLE1BQU07RUFDTixTQUFTO0VBQ1QsVUFBVTtFQUNWLG9CQUFvQjtFQUNwQixVQUFVO0NBQ1g7O0NBRUE7RUFDQyxPQUFPO0VBQ1A7Ozs7R0FJQztDQUNGOztDQUVBO0VBQ0MsUUFBUTtFQUNSOzs7O0dBSUM7Q0FDRjtBQUNEIiwiZmlsZSI6InRlc3RpbW9uaWFscy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG4udGV4dC1jbGFtcC0zIHtcblx0ZGlzcGxheTogLXdlYmtpdC1ib3g7XG5cdC13ZWJraXQtbGluZS1jbGFtcDogMztcblx0LXdlYmtpdC1ib3gtb3JpZW50OiB2ZXJ0aWNhbDtcblx0b3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLnRleHQtY2xhbXAtNSB7XG5cdGRpc3BsYXk6IC13ZWJraXQtYm94O1xuXHQtd2Via2l0LWxpbmUtY2xhbXA6IDU7XG5cdC13ZWJraXQtYm94LW9yaWVudDogdmVydGljYWw7XG5cdG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi50ZXN0aW1vbmlhbC1jYXJkIHtcblx0Ym94LXNpemluZzogYm9yZGVyLWJveDtcbn1cblxuLmNhcm91c2VsLXZpZXdwb3J0IHtcblx0cG9zaXRpb246IHJlbGF0aXZlO1xuXHQvKiBTbW9vdGggZWRnZSBmYWRlIHdpdGhvdXQgY2hhbmdpbmcgY2Fyb3VzZWwgbG9naWMgKi9cblx0LXdlYmtpdC1tYXNrLWltYWdlOiBsaW5lYXItZ3JhZGllbnQoXG5cdFx0dG8gcmlnaHQsXG5cdFx0dHJhbnNwYXJlbnQgMCUsXG5cdFx0YmxhY2sgOCUsXG5cdFx0YmxhY2sgOTIlLFxuXHRcdHRyYW5zcGFyZW50IDEwMCVcblx0KTtcblx0bWFzay1pbWFnZTogbGluZWFyLWdyYWRpZW50KFxuXHRcdHRvIHJpZ2h0LFxuXHRcdHRyYW5zcGFyZW50IDAlLFxuXHRcdGJsYWNrIDglLFxuXHRcdGJsYWNrIDkyJSxcblx0XHR0cmFuc3BhcmVudCAxMDAlXG5cdCk7XG59XG5cbkBzdXBwb3J0cyBub3QgKG1hc2staW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCwgdHJhbnNwYXJlbnQsIGJsYWNrKSkge1xuXHQuY2Fyb3VzZWwtdmlld3BvcnQ6OmJlZm9yZSxcblx0LmNhcm91c2VsLXZpZXdwb3J0OjphZnRlciB7XG5cdFx0Y29udGVudDogJyc7XG5cdFx0cG9zaXRpb246IGFic29sdXRlO1xuXHRcdHRvcDogMDtcblx0XHRib3R0b206IDA7XG5cdFx0d2lkdGg6IDEyJTtcblx0XHRwb2ludGVyLWV2ZW50czogbm9uZTtcblx0XHR6LWluZGV4OiA1O1xuXHR9XG5cblx0LmNhcm91c2VsLXZpZXdwb3J0OjpiZWZvcmUge1xuXHRcdGxlZnQ6IDA7XG5cdFx0YmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KFxuXHRcdFx0dG8gcmlnaHQsXG5cdFx0XHR2YXIoLS1jb2xvci1wYWdlLWJnLCAjMGYxNzJhKSAwJSxcblx0XHRcdHJnYmEoMTUsIDIzLCA0MiwgMCkgMTAwJVxuXHRcdCk7XG5cdH1cblxuXHQuY2Fyb3VzZWwtdmlld3BvcnQ6OmFmdGVyIHtcblx0XHRyaWdodDogMDtcblx0XHRiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoXG5cdFx0XHR0byBsZWZ0LFxuXHRcdFx0dmFyKC0tY29sb3ItcGFnZS1iZywgIzBmMTcyYSkgMCUsXG5cdFx0XHRyZ2JhKDE1LCAyMywgNDIsIDApIDEwMCVcblx0XHQpO1xuXHR9XG59XG5cblxuIl19 */\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvY29tcG9uZW50cy90ZXN0aW1vbmlhbHMvdGVzdGltb25pYWxzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUNBO0NBQ0Msb0JBQW9CO0NBQ3BCLHFCQUFxQjtDQUNyQiw0QkFBNEI7Q0FDNUIsZ0JBQWdCO0FBQ2pCOztBQUVBO0NBQ0Msb0JBQW9CO0NBQ3BCLHFCQUFxQjtDQUNyQiw0QkFBNEI7Q0FDNUIsZ0JBQWdCO0FBQ2pCOztBQUVBO0NBQ0Msc0JBQXNCO0FBQ3ZCOztBQUVBO0NBQ0Msa0JBQWtCO0NBQ2xCLHFEQUFxRDtDQVFyRDs7Ozs7O0VBTUM7QUFDRjs7QUFFQTtDQUNDOztFQUVDLFdBQVc7RUFDWCxrQkFBa0I7RUFDbEIsTUFBTTtFQUNOLFNBQVM7RUFDVCxVQUFVO0VBQ1Ysb0JBQW9CO0VBQ3BCLFVBQVU7Q0FDWDs7Q0FFQTtFQUNDLE9BQU87RUFDUDs7OztHQUlDO0NBQ0Y7O0NBRUE7RUFDQyxRQUFRO0VBQ1I7Ozs7R0FJQztDQUNGO0FBQ0Q7Ozs7QUFIQSxvOEVBQW84RSIsInNvdXJjZXNDb250ZW50IjpbIlxuLnRleHQtY2xhbXAtMyB7XG5cdGRpc3BsYXk6IC13ZWJraXQtYm94O1xuXHQtd2Via2l0LWxpbmUtY2xhbXA6IDM7XG5cdC13ZWJraXQtYm94LW9yaWVudDogdmVydGljYWw7XG5cdG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi50ZXh0LWNsYW1wLTUge1xuXHRkaXNwbGF5OiAtd2Via2l0LWJveDtcblx0LXdlYmtpdC1saW5lLWNsYW1wOiA1O1xuXHQtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xuXHRvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4udGVzdGltb25pYWwtY2FyZCB7XG5cdGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG59XG5cbi5jYXJvdXNlbC12aWV3cG9ydCB7XG5cdHBvc2l0aW9uOiByZWxhdGl2ZTtcblx0LyogU21vb3RoIGVkZ2UgZmFkZSB3aXRob3V0IGNoYW5naW5nIGNhcm91c2VsIGxvZ2ljICovXG5cdC13ZWJraXQtbWFzay1pbWFnZTogbGluZWFyLWdyYWRpZW50KFxuXHRcdHRvIHJpZ2h0LFxuXHRcdHRyYW5zcGFyZW50IDAlLFxuXHRcdGJsYWNrIDglLFxuXHRcdGJsYWNrIDkyJSxcblx0XHR0cmFuc3BhcmVudCAxMDAlXG5cdCk7XG5cdG1hc2staW1hZ2U6IGxpbmVhci1ncmFkaWVudChcblx0XHR0byByaWdodCxcblx0XHR0cmFuc3BhcmVudCAwJSxcblx0XHRibGFjayA4JSxcblx0XHRibGFjayA5MiUsXG5cdFx0dHJhbnNwYXJlbnQgMTAwJVxuXHQpO1xufVxuXG5Ac3VwcG9ydHMgbm90IChtYXNrLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQsIHRyYW5zcGFyZW50LCBibGFjaykpIHtcblx0LmNhcm91c2VsLXZpZXdwb3J0OjpiZWZvcmUsXG5cdC5jYXJvdXNlbC12aWV3cG9ydDo6YWZ0ZXIge1xuXHRcdGNvbnRlbnQ6ICcnO1xuXHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcblx0XHR0b3A6IDA7XG5cdFx0Ym90dG9tOiAwO1xuXHRcdHdpZHRoOiAxMiU7XG5cdFx0cG9pbnRlci1ldmVudHM6IG5vbmU7XG5cdFx0ei1pbmRleDogNTtcblx0fVxuXG5cdC5jYXJvdXNlbC12aWV3cG9ydDo6YmVmb3JlIHtcblx0XHRsZWZ0OiAwO1xuXHRcdGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudChcblx0XHRcdHRvIHJpZ2h0LFxuXHRcdFx0dmFyKC0tY29sb3ItcGFnZS1iZywgIzBmMTcyYSkgMCUsXG5cdFx0XHRyZ2JhKDE1LCAyMywgNDIsIDApIDEwMCVcblx0XHQpO1xuXHR9XG5cblx0LmNhcm91c2VsLXZpZXdwb3J0OjphZnRlciB7XG5cdFx0cmlnaHQ6IDA7XG5cdFx0YmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KFxuXHRcdFx0dG8gbGVmdCxcblx0XHRcdHZhcigtLWNvbG9yLXBhZ2UtYmcsICMwZjE3MmEpIDAlLFxuXHRcdFx0cmdiYSgxNSwgMjMsIDQyLCAwKSAxMDAlXG5cdFx0KTtcblx0fVxufVxuXG5cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}

/***/ }),

/***/ 7854:
/*!*****************************************************!*\
  !*** ./src/app/core/analytics/analytics.service.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AnalyticsService: () => (/* binding */ AnalyticsService)
/* harmony export */ });
/* harmony import */ var _Users_felipe_develop_easy_locker_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9204);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase/app */ 6725);
/* harmony import */ var firebase_analytics__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! firebase/analytics */ 984);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 819);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 1567);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 3900);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../environments/environment */ 5312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _services_cookie_consent_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/cookie-consent.service */ 1845);










class AnalyticsService {
  constructor(router, consent) {
    this.router = router;
    this.consent = consent;
    this.app = null;
    this.analytics = null;
    this.pendingEvents = [];
    this.destroy$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subject();
    this.initializationAttempted = false;
    this.observeConsentChanges();
    this.registerRouterTracking();
  }
  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }
  trackEvent(eventName, params = {}) {
    if (!this.consent.analyticsEnabled) {
      return;
    }
    if (!this.analytics) {
      this.pendingEvents.push({
        name: eventName,
        params
      });
      this.init();
      return;
    }
    this.dispatchEvent(eventName, params);
  }
  registerRouterTracking() {
    this.router.events.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.filter)(event => event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_7__.NavigationEnd), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.destroy$)).subscribe(event => this.trackPageView(event.urlAfterRedirects));
  }
  trackPageView(path) {
    if (typeof window === 'undefined' || !this.consent.analyticsEnabled) {
      return;
    }
    this.trackEvent('page_view', {
      page_path: path,
      page_location: window.location.href,
      page_title: typeof document !== 'undefined' ? document.title : undefined
    });
  }
  dispatchEvent(eventName, params) {
    if (!this.analytics || !this.consent.analyticsEnabled) {
      return;
    }
    const payload = {
      ...this.getCommonEventParams(),
      ...params
    };
    (0,firebase_analytics__WEBPACK_IMPORTED_MODULE_2__.logEvent)(this.analytics, eventName, payload);
  }
  flushPendingEvents() {
    if (!this.analytics || !this.pendingEvents.length) {
      return;
    }
    const queue = [...this.pendingEvents];
    this.pendingEvents = [];
    queue.forEach(({
      name,
      params
    }) => this.dispatchEvent(name, params));
  }
  getCommonEventParams() {
    const lang = typeof document !== 'undefined' ? document.documentElement.lang || 'es' : 'es';
    const storedTheme = typeof localStorage !== 'undefined' ? localStorage.getItem('theme-preference') : null;
    return {
      lang,
      theme: this.normalizeTheme(storedTheme)
    };
  }
  normalizeTheme(value) {
    if (value === 'light' || value === 'dark') {
      return value;
    }
    return 'system';
  }
  observeConsentChanges() {
    this.consent.consent$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.takeUntil)(this.destroy$)).subscribe(consent => {
      if (consent?.analytics) {
        this.init();
      } else {
        if (this.analytics) {
          (0,firebase_analytics__WEBPACK_IMPORTED_MODULE_2__.setAnalyticsCollectionEnabled)(this.analytics, false);
        }
        this.pendingEvents = [];
        this.initializationAttempted = false;
      }
    });
  }
  init() {
    var _this = this;
    if (this.initializationAttempted || !this.consent.analyticsEnabled) {
      return;
    }
    this.initializationAttempted = true;
    this.initPromise = (0,_Users_felipe_develop_easy_locker_web_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        const supported = yield (0,firebase_analytics__WEBPACK_IMPORTED_MODULE_2__.isSupported)();
        if (!supported) {
          console.warn('[Analytics] No soportado en este navegador');
          return;
        }
        _this.app = (0,firebase_app__WEBPACK_IMPORTED_MODULE_1__.initializeApp)(_environments_environment__WEBPACK_IMPORTED_MODULE_3__.environment.firebaseConfig);
        _this.analytics = (0,firebase_analytics__WEBPACK_IMPORTED_MODULE_2__.getAnalytics)(_this.app);
        (0,firebase_analytics__WEBPACK_IMPORTED_MODULE_2__.setAnalyticsCollectionEnabled)(_this.analytics, true);
        console.info('[Analytics] Inicializado OK');
        _this.trackEvent('easy_init');
        _this.flushPendingEvents();
      } catch (error) {
        console.warn('[Analytics] No se pudo inicializar Firebase Analytics', error);
      }
    })();
  }
  static {
    this.ɵfac = function AnalyticsService_Factory(t) {
      return new (t || AnalyticsService)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵinject"](_services_cookie_consent_service__WEBPACK_IMPORTED_MODULE_4__.CookieConsentService));
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineInjectable"]({
      token: AnalyticsService,
      factory: AnalyticsService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 1845:
/*!*********************************************************!*\
  !*** ./src/app/core/services/cookie-consent.service.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CookieConsentService: () => (/* binding */ CookieConsentService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 5797);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);


const CONSENT_KEY = 'easy-cookie-consent';
const CONSENT_VERSION = 1;
class CookieConsentService {
  constructor() {
    this.consentSubject = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject(this.load());
    this.consent$ = this.consentSubject.asObservable();
  }
  get current() {
    return this.consentSubject.value;
  }
  get hasAnswered() {
    return !!this.current;
  }
  get analyticsEnabled() {
    return !!this.current?.analytics;
  }
  acceptAnalytics() {
    this.save({
      version: CONSENT_VERSION,
      analytics: true,
      updatedAt: new Date().toISOString()
    });
  }
  rejectAnalytics() {
    this.save({
      version: CONSENT_VERSION,
      analytics: false,
      updatedAt: new Date().toISOString()
    });
  }
  load() {
    if (typeof window === 'undefined' || typeof localStorage === 'undefined') {
      return null;
    }
    try {
      const raw = localStorage.getItem(CONSENT_KEY);
      if (!raw) {
        return null;
      }
      const parsed = JSON.parse(raw);
      if (parsed.version !== CONSENT_VERSION) {
        return null;
      }
      return parsed;
    } catch (error) {
      return null;
    }
  }
  save(consent) {
    if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
      try {
        localStorage.setItem(CONSENT_KEY, JSON.stringify(consent));
      } catch (error) {
        // Ignore storage persistence errors
      }
    }
    this.consentSubject.next(consent);
  }
  static {
    this.ɵfac = function CookieConsentService_Factory(t) {
      return new (t || CookieConsentService)();
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
      token: CookieConsentService,
      factory: CookieConsentService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 4199:
/*!****************************************************************!*\
  !*** ./src/app/pages/cookie-policy/cookie-policy.component.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CookiePolicyComponent: () => (/* binding */ CookiePolicyComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _components_language_switcher_language_switcher_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../components/language-switcher/language-switcher.component */ 5457);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ 852);



class CookiePolicyComponent {
  static {
    this.ɵfac = function CookiePolicyComponent_Factory(t) {
      return new (t || CookiePolicyComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: CookiePolicyComponent,
      selectors: [["app-cookie-policy"]],
      decls: 177,
      vars: 138,
      consts: [[1, "mx-auto", "max-w-4xl", "px-4", "py-12", "text-brand-textPrimary"], [1, "mb-6", "flex", "justify-end"], ["aria-label", "Selector de idiomas"], [1, "mb-10"], [1, "text-xs", "font-semibold", "uppercase", "tracking-[0.3em]", "text-brand-textMuted"], [1, "mt-2", "text-3xl", "font-bold", "text-brand-textPrimary"], [1, "mt-3", "text-base", "text-brand-textSecondary"], [1, "space-y-10", "text-base", "leading-relaxed", "text-brand-textSecondary"], ["id", "responsable", 1, "space-y-3"], [1, "text-2xl", "font-semibold", "text-brand-textPrimary"], [1, "list-disc", "space-y-1", "pl-6"], ["href", "mailto:info@easy-locker.com", 1, "underline"], [1, "text-sm", "text-brand-textMuted"], ["id", "definicion", 1, "space-y-3"], ["id", "tipos", 1, "space-y-3"], [1, "rounded-2xl", "border", "border-brand-border", "bg-brand-surface", "p-5", "shadow-sm"], [1, "text-xl", "font-semibold", "text-brand-textPrimary"], [1, "mt-2"], [1, "mt-2", "list-disc", "space-y-1", "pl-6"], [1, "mt-3", "font-semibold", "text-brand-textPrimary"], ["id", "lista", 1, "space-y-3"], [1, "overflow-hidden", "rounded-2xl", "border", "border-brand-border"], [1, "w-full", "text-left", "text-sm"], [1, "bg-brand-background", "text-brand-textPrimary"], [1, "px-4", "py-2"], [1, "divide-y", "divide-brand-border", "bg-brand-surface"], [1, "px-4", "py-3", "font-medium"], [1, "px-4", "py-3"], ["id", "gestion", 1, "space-y-3"], ["id", "transferencias", 1, "space-y-3"], ["id", "actualizaciones", 1, "space-y-3"]],
      template: function CookiePolicyComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "section", 0)(1, "div", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "app-language-switcher", 2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "header", 3)(4, "p", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5, " Easy Locker ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "h1", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](8, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "p", 6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](11, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "article", 7)(13, "section", 8)(14, "h2", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](16, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](18);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](19, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](20, "ul", 10)(21, "li");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](22);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](23, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](24, "a", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](25, "info@easy-locker.com");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](26, "li");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](27);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](28, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](29, "p", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](30);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](31, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](32, "section", 13)(33, "h2", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](34);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](35, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](36, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](37);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](38, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](39, "section", 14)(40, "h2", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](41);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](42, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](43, "div", 15)(44, "h3", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](45);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](46, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](47, "p", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](48);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](49, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](50, "ul", 18)(51, "li");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](52);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](53, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](54, "li");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](55);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](56, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](57, "li");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](58);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](59, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](60, "p", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](61);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](62, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](63, "div", 15)(64, "h3", 16);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](65);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](66, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](67, "p", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](68);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](69, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](70, "p", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](71);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](72, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](73, "ul", 10)(74, "li");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](75);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](76, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](77, "li");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](78);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](79, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](80, "li");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](81);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](82, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](83, "p", 19);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](84);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](85, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](86, "ul", 10)(87, "li");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](88);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](89, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](90, "li");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](91);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](92, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](93, "li");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](94);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](95, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](96, "p", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](97);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](98, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](99, "section", 20)(100, "h2", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](101);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](102, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](103, "div", 21)(104, "table", 22)(105, "thead", 23)(106, "tr")(107, "th", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](108);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](109, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](110, "th", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](111);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](112, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](113, "th", 24);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](114);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](115, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](116, "tbody", 25)(117, "tr")(118, "td", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](119, "easy-lang");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](120, "td", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](121);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](122, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](123, "td", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](124);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](125, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](126, "tr")(127, "td", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](128, "easy-theme");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](129, "td", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](130);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](131, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](132, "td", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](133);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](134, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](135, "tr")(136, "td", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](137, "easy-cookie-consent");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](138, "td", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](139);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](140, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](141, "td", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](142);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](143, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](144, "tr")(145, "td", 26);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](146, "_ga, _ga_*");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](147, "td", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](148);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](149, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](150, "td", 27);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](151);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](152, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](153, "p", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](154);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](155, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](156, "section", 28)(157, "h2", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](158);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](159, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](160, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](161);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](162, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](163, "section", 29)(164, "h2", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](165);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](166, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](167, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](168);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](169, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](170, "section", 30)(171, "h2", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](172);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](173, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](174, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](175);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](176, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](8, 46, "cookiePolicy.title"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](11, 48, "cookiePolicy.summary"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](16, 50, "cookiePolicy.sections.responsible.title"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](19, 52, "cookiePolicy.sections.responsible.body"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](23, 54, "cookiePolicy.sections.responsible.list.email"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](28, 56, "cookiePolicy.sections.responsible.list.purpose"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](31, 58, "cookiePolicy.sections.responsible.note"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](35, 60, "cookiePolicy.sections.definition.title"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](38, 62, "cookiePolicy.sections.definition.body"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](42, 64, "cookiePolicy.sections.types.title"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](46, 66, "cookiePolicy.sections.types.essential.title"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](49, 68, "cookiePolicy.sections.types.essential.intro"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](53, 70, "cookiePolicy.sections.types.essential.items.language"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](56, 72, "cookiePolicy.sections.types.essential.items.theme"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](59, 74, "cookiePolicy.sections.types.essential.items.consent"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](62, 76, "cookiePolicy.sections.types.essential.legal"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](66, 78, "cookiePolicy.sections.types.analytics.title"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](69, 80, "cookiePolicy.sections.types.analytics.intro"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](72, 82, "cookiePolicy.sections.types.analytics.dataTitle"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](76, 84, "cookiePolicy.sections.types.analytics.dataItems.device"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](79, 86, "cookiePolicy.sections.types.analytics.dataItems.tech"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](82, 88, "cookiePolicy.sections.types.analytics.dataItems.usage"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](85, 90, "cookiePolicy.sections.types.analytics.notStoredTitle"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](89, 92, "cookiePolicy.sections.types.analytics.notStoredItems.names"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](92, 94, "cookiePolicy.sections.types.analytics.notStoredItems.contact"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](95, 96, "cookiePolicy.sections.types.analytics.notStoredItems.booking"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](98, 98, "cookiePolicy.sections.types.analytics.legal"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](102, 100, "cookiePolicy.sections.list.title"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](109, 102, "cookiePolicy.sections.list.table.name"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](112, 104, "cookiePolicy.sections.list.table.type"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](115, 106, "cookiePolicy.sections.list.table.purpose"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](122, 108, "cookiePolicy.sections.list.labels.essential"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](125, 110, "cookiePolicy.sections.list.rows.easyLang.purpose"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](131, 112, "cookiePolicy.sections.list.labels.essential"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](134, 114, "cookiePolicy.sections.list.rows.easyTheme.purpose"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](140, 116, "cookiePolicy.sections.list.labels.essential"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](143, 118, "cookiePolicy.sections.list.rows.easyConsent.purpose"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](149, 120, "cookiePolicy.sections.list.labels.analytics"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](152, 122, "cookiePolicy.sections.list.rows.ga.purpose"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](155, 124, "cookiePolicy.sections.list.notice"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](159, 126, "cookiePolicy.sections.manage.title"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](162, 128, "cookiePolicy.sections.manage.body"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](166, 130, "cookiePolicy.sections.transfer.title"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](169, 132, "cookiePolicy.sections.transfer.body"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](173, 134, "cookiePolicy.sections.updates.title"), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](176, 136, "cookiePolicy.sections.updates.body"), " ");
        }
      },
      dependencies: [_components_language_switcher_language_switcher_component__WEBPACK_IMPORTED_MODULE_0__.LanguageSwitcherComponent, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslatePipe],
      styles: ["[_nghost-%COMP%] {\n  display: block;\n}\n\nsection[_ngcontent-%COMP%] {\n  color: var(--brand-text-primary);\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvb2tpZS1wb2xpY3kuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGNBQWM7QUFDaEI7O0FBRUE7RUFDRSxnQ0FBZ0M7QUFDbEMiLCJmaWxlIjoiY29va2llLXBvbGljeS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xuICBkaXNwbGF5OiBibG9jaztcbn1cblxuc2VjdGlvbiB7XG4gIGNvbG9yOiB2YXIoLS1icmFuZC10ZXh0LXByaW1hcnkpO1xufVxuIl19 */\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvY29va2llLXBvbGljeS9jb29raWUtcG9saWN5LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxjQUFjO0FBQ2hCOztBQUVBO0VBQ0UsZ0NBQWdDO0FBQ2xDOztBQUVBLHdaQUF3WiIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cbnNlY3Rpb24ge1xuICBjb2xvcjogdmFyKC0tYnJhbmQtdGV4dC1wcmltYXJ5KTtcbn1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}

/***/ }),

/***/ 5047:
/*!**********************************************!*\
  !*** ./src/app/pages/home/home.component.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   HomeComponent: () => (/* binding */ HomeComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _components_header_header_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../components/header/header.component */ 385);
/* harmony import */ var _components_hero_hero_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../components/hero/hero.component */ 9307);
/* harmony import */ var _components_faq_faq_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/faq/faq.component */ 9613);
/* harmony import */ var _components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../components/footer/footer.component */ 5473);
/* harmony import */ var _components_pricing_pricing_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/pricing/pricing.component */ 2185);
/* harmony import */ var _components_testimonials_testimonials_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/testimonials/testimonials.component */ 5375);







class HomeComponent {
  static {
    this.ɵfac = function HomeComponent_Factory(t) {
      return new (t || HomeComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({
      type: HomeComponent,
      selectors: [["app-home"]],
      decls: 7,
      vars: 0,
      consts: [[1, "bg-brand-surfaceSubtle/95", "dark:bg-brand-darkSurface/95", "transition-colors", "duration-300"]],
      template: function HomeComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](0, "app-header")(1, "app-hero");
          _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "main", 0);
          _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](3, "app-pricing")(4, "app-testimonials")(5, "app-faq");
          _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](6, "app-footer");
        }
      },
      dependencies: [_components_header_header_component__WEBPACK_IMPORTED_MODULE_0__.HeaderComponent, _components_hero_hero_component__WEBPACK_IMPORTED_MODULE_1__.HeroComponent, _components_faq_faq_component__WEBPACK_IMPORTED_MODULE_2__.FaqComponent, _components_footer_footer_component__WEBPACK_IMPORTED_MODULE_3__.FooterComponent, _components_pricing_pricing_component__WEBPACK_IMPORTED_MODULE_4__.PricingComponent, _components_testimonials_testimonials_component__WEBPACK_IMPORTED_MODULE_5__.TestimonialsComponent],
      styles: ["/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJob21lLmNvbXBvbmVudC5jc3MifQ== */\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvcGFnZXMvaG9tZS9ob21lLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUNBLGdLQUFnSyIsInNvdXJjZVJvb3QiOiIifQ== */"]
    });
  }
}

/***/ }),

/***/ 3636:
/*!**********************************************************!*\
  !*** ./src/app/services/dropdown-coordinator.service.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DropdownCoordinatorService: () => (/* binding */ DropdownCoordinatorService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 5797);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);


class DropdownCoordinatorService {
  constructor() {
    this.openDropdownSubject = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject(null);
    this.openDropdown$ = this.openDropdownSubject.asObservable();
  }
  toggle(dropdownId) {
    const current = this.openDropdownSubject.value;
    this.openDropdownSubject.next(current === dropdownId ? null : dropdownId);
  }
  close(dropdownId) {
    if (this.openDropdownSubject.value === dropdownId) {
      this.openDropdownSubject.next(null);
    }
  }
  forceCloseAll() {
    this.openDropdownSubject.next(null);
  }
  static {
    this.ɵfac = function DropdownCoordinatorService_Factory(t) {
      return new (t || DropdownCoordinatorService)();
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
      token: DropdownCoordinatorService,
      factory: DropdownCoordinatorService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 8756:
/*!**********************************************!*\
  !*** ./src/app/services/language.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LanguageService: () => (/* binding */ LanguageService)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 5797);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ 852);
/* harmony import */ var _core_analytics_analytics_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../core/analytics/analytics.service */ 7854);





class LanguageService {
  constructor(translate, document, analytics) {
    this.translate = translate;
    this.document = document;
    this.analytics = analytics;
    this.storageKey = 'language';
    this.defaultLanguage = 'en';
    this.supportedLanguages = [{
      code: 'es',
      labelKey: 'header.language.options.es'
    }, {
      code: 'en',
      labelKey: 'header.language.options.en'
    }, {
      code: 'fr',
      labelKey: 'header.language.options.fr'
    }, {
      code: 'de',
      labelKey: 'header.language.options.de'
    }, {
      code: 'it',
      labelKey: 'header.language.options.it'
    }];
    this.initialized = false;
    this.languageSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(this.defaultLanguage);
    this.language$ = this.languageSubject.asObservable();
  }
  init() {
    if (this.initialized) {
      return;
    }
    this.initialized = true;
    this.translate.setDefaultLang(this.defaultLanguage);
    this.translate.addLangs(this.supportedLanguages.map(lang => lang.code));
    const stored = this.getStoredLanguage();
    if (stored) {
      this.applyLanguage(stored, false);
      return;
    }
    const detected = this.detectBrowserLanguage();
    this.applyLanguage(detected ?? this.defaultLanguage, false);
  }
  setLanguage(languageCode) {
    this.applyLanguage(languageCode, true);
  }
  getSupportedLanguages() {
    return this.supportedLanguages;
  }
  getCurrentLanguage() {
    return this.languageSubject.value;
  }
  applyLanguage(languageCode, persist) {
    const normalized = this.normalizeLocale(languageCode);
    const finalLang = this.isSupported(normalized) ? normalized : this.defaultLanguage;
    const previous = this.languageSubject.value;
    this.translate.use(finalLang);
    this.languageSubject.next(finalLang);
    this.updateDocumentLanguage(finalLang);
    if (persist) {
      this.persistLanguage(finalLang);
      if (previous !== finalLang) {
        this.analytics.trackEvent('nav_change_language', {
          previous_lang: previous,
          new_lang: finalLang
        });
      }
    }
  }
  getStoredLanguage() {
    if (typeof window === 'undefined' || typeof localStorage === 'undefined') {
      return null;
    }
    try {
      const stored = localStorage.getItem(this.storageKey);
      return stored && this.isSupported(stored) ? stored : null;
    } catch (error) {
      return null;
    }
  }
  detectBrowserLanguage() {
    if (typeof window === 'undefined' || typeof navigator === 'undefined') {
      return null;
    }
    const preferred = navigator.languages && navigator.languages.length > 0 ? navigator.languages : navigator.language ? [navigator.language] : [];
    for (const locale of preferred) {
      const normalized = this.normalizeLocale(locale);
      if (this.isSupported(normalized)) {
        return normalized;
      }
    }
    return null;
  }
  normalizeLocale(locale) {
    if (!locale) {
      return '';
    }
    return locale.toLowerCase().split('-')[0];
  }
  isSupported(code) {
    return this.supportedLanguages.some(lang => lang.code === code);
  }
  updateDocumentLanguage(lang) {
    try {
      if (this.document?.documentElement) {
        this.document.documentElement.lang = lang;
      }
    } catch (error) {
      // ignore document write errors
    }
  }
  persistLanguage(lang) {
    if (typeof window === 'undefined' || typeof localStorage === 'undefined') {
      return;
    }
    try {
      localStorage.setItem(this.storageKey, lang);
    } catch (error) {
      // Ignore storage errors (e.g., privacy mode)
    }
  }
  static {
    this.ɵfac = function LanguageService_Factory(t) {
      return new (t || LanguageService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__.TranslateService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common__WEBPACK_IMPORTED_MODULE_4__.DOCUMENT), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_core_analytics_analytics_service__WEBPACK_IMPORTED_MODULE_0__.AnalyticsService));
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
      token: LanguageService,
      factory: LanguageService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 487:
/*!*******************************************!*\
  !*** ./src/app/services/theme.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ThemeService: () => (/* binding */ ThemeService)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 5797);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _core_analytics_analytics_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../core/analytics/analytics.service */ 7854);




const THEME_STORAGE_KEY = 'theme-preference';
class ThemeService {
  constructor(document, analytics) {
    this.document = document;
    this.analytics = analytics;
    this.preference = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('system');
    this.darkMode = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(false);
    this.preference$ = this.preference.asObservable();
    this.darkMode$ = this.darkMode.asObservable();
    this.mediaListener = event => {
      if (this.preference.value === 'system') {
        this.applyDarkMode(event.matches);
      }
    };
    if (typeof window !== 'undefined') {
      this.mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      this.mediaQuery.addEventListener('change', this.mediaListener);
    }
    const storedPreference = this.readStoredPreference();
    this.setPreference(storedPreference, false);
  }
  ngOnDestroy() {
    if (this.mediaQuery) {
      this.mediaQuery.removeEventListener('change', this.mediaListener);
    }
  }
  setPreference(preference, persist = true) {
    const previous = this.preference.value;
    this.preference.next(preference);
    const shouldUseDark = this.resolveIsDark(preference);
    this.applyDarkMode(shouldUseDark);
    if (!persist) {
      return;
    }
    this.persistPreference(preference);
    if (previous !== preference) {
      this.analytics.trackEvent('nav_change_theme', {
        previous_theme: previous,
        new_theme: preference
      });
    }
  }
  cyclePreference() {
    const order = ['light', 'dark', 'system'];
    const currentIndex = order.indexOf(this.preference.value);
    const nextPreference = order[(currentIndex + 1) % order.length];
    this.setPreference(nextPreference);
  }
  resolveIsDark(preference) {
    if (preference === 'dark') {
      return true;
    }
    if (preference === 'light') {
      return false;
    }
    return this.mediaQuery ? this.mediaQuery.matches : false;
  }
  applyDarkMode(isDark) {
    this.darkMode.next(isDark);
    const classList = this.document?.documentElement.classList;
    if (!classList) {
      return;
    }
    classList.toggle('dark', isDark);
  }
  readStoredPreference() {
    if (typeof window === 'undefined' || typeof localStorage === 'undefined') {
      return 'system';
    }
    try {
      const stored = localStorage.getItem(THEME_STORAGE_KEY);
      if (stored === 'light' || stored === 'dark') {
        return stored;
      }
      const legacy = localStorage.getItem('theme');
      if (legacy === 'light' || legacy === 'dark') {
        localStorage.removeItem('theme');
        localStorage.setItem(THEME_STORAGE_KEY, legacy);
        return legacy;
      }
    } catch (error) {
      // Ignore storage failures and fall back to system
    }
    return 'system';
  }
  persistPreference(preference) {
    if (typeof window === 'undefined' || typeof localStorage === 'undefined') {
      return;
    }
    try {
      if (preference === 'system') {
        localStorage.removeItem(THEME_STORAGE_KEY);
      } else {
        localStorage.setItem(THEME_STORAGE_KEY, preference);
      }
    } catch (error) {
      // Ignore storage access issues (e.g., private mode)
    }
  }
  static {
    this.ɵfac = function ThemeService_Factory(t) {
      return new (t || ThemeService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common__WEBPACK_IMPORTED_MODULE_3__.DOCUMENT), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_core_analytics_analytics_service__WEBPACK_IMPORTED_MODULE_0__.AnalyticsService));
    };
  }
  static {
    this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
      token: ThemeService,
      factory: ThemeService.ɵfac,
      providedIn: 'root'
    });
  }
}

/***/ }),

/***/ 5109:
/*!****************************************************************************!*\
  !*** ./src/app/shared/components/cookie-banner/cookie-banner.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CookieBannerComponent: () => (/* binding */ CookieBannerComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _core_services_cookie_consent_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../core/services/cookie-consent.service */ 1845);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 316);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 5072);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ 852);





const _c0 = function () {
  return {
    default: "Permitir cookies de an\u00E1lisis"
  };
};
function CookieBannerComponent_div_33_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 18)(1, "label", 19)(2, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](4, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "button", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CookieBannerComponent_div_33_Template_button_click_5_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r2);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r1.cookieConsent.analyticsEnabled ? ctx_r1.acceptEssential() : ctx_r1.acceptAll());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "span", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](4, 10, "cookies.preferences.analytics_label", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](13, _c0)), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassProp"]("bg-brand-accentPrimary", ctx_r0.cookieConsent.analyticsEnabled)("bg-brand-border", !ctx_r0.cookieConsent.analyticsEnabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵattribute"]("aria-pressed", ctx_r0.cookieConsent.analyticsEnabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassProp"]("translate-x-5", ctx_r0.cookieConsent.analyticsEnabled)("translate-x-1", !ctx_r0.cookieConsent.analyticsEnabled);
  }
}
const _c1 = function () {
  return {
    default: "Tus preferencias de cookies"
  };
};
const _c2 = "Usamos cookies esenciales para que el sitio funcione y anal\u00EDticas opcionales para mejorar la experiencia. Puedes aceptar solo las necesarias o todas.";
const _c3 = function () {
  return {
    default: _c2
  };
};
const _c4 = function () {
  return {
    default: "Esenciales"
  };
};
const _c5 = function () {
  return {
    default: "Siempre activas"
  };
};
const _c6 = "Idioma, tema y funciones b\u00E1sicas necesarias para que Easy Locker funcione.";
const _c7 = function () {
  return {
    default: _c6
  };
};
const _c8 = function () {
  return {
    default: "Anal\u00EDticas"
  };
};
const _c9 = function () {
  return {
    default: "Ocultar"
  };
};
const _c10 = function () {
  return {
    default: "Configurar"
  };
};
const _c11 = "Nos ayudan a entender el uso del sitio y mejorar nuestros servicios.";
const _c12 = function () {
  return {
    default: _c11
  };
};
const _c13 = function () {
  return {
    default: "Aceptar solo esenciales"
  };
};
const _c14 = function () {
  return {
    default: "Aceptar todas"
  };
};
const _c15 = function () {
  return {
    default: "Pol\u00EDtica de cookies"
  };
};
class CookieBannerComponent {
  constructor(cookieConsent) {
    this.cookieConsent = cookieConsent;
    this.showPreferences = false;
  }
  acceptAll() {
    this.cookieConsent.acceptAnalytics();
  }
  acceptEssential() {
    this.cookieConsent.rejectAnalytics();
  }
  togglePreferences() {
    this.showPreferences = !this.showPreferences;
  }
  static {
    this.ɵfac = function CookieBannerComponent_Factory(t) {
      return new (t || CookieBannerComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_core_services_cookie_consent_service__WEBPACK_IMPORTED_MODULE_0__.CookieConsentService));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: CookieBannerComponent,
      selectors: [["app-cookie-banner"]],
      decls: 45,
      vars: 60,
      consts: [["role", "presentation", 1, "cookie-overlay", "fixed", "inset-0", "flex", "items-end", "justify-center", "bg-black/40", "px-4", "pb-6", "pt-4", "md:items-end", "md:justify-end", "md:px-8", "md:pb-8"], ["role", "dialog", "aria-modal", "true", "aria-label", "Aviso de cookies", "tabindex", "-1", 1, "mx-auto", "mt-auto", "mb-6", "w-full", "max-w-[480px]", "rounded-2xl", "border", "border-brand-border", "bg-brand-surface", "px-5", "py-5", "shadow-2xl", "transition-all", "md:mx-0", "md:mb-0", "md:max-w-md", "md:px-6", "md:py-5", "md:shadow-xl"], [1, "flex", "flex-col", "gap-4"], [1, "text-lg", "font-semibold", "text-brand-textPrimary"], [1, "mt-1", "text-sm", "text-brand-textSecondary"], [1, "flex", "flex-col", "gap-3", "rounded-xl", "bg-brand-background", "px-4", "py-3", "text-sm", "text-brand-textSecondary"], [1, "flex", "items-center", "justify-between"], [1, "font-medium", "text-brand-textPrimary"], [1, "rounded-full", "bg-green-100", "px-3", "py-1", "text-xs", "font-semibold", "uppercase", "tracking-wide", "text-green-700"], [1, "border-t", "border-brand-border", "pt-3"], ["type", "button", 1, "rounded-full", "border", "border-brand-border", "px-3", "py-1", "text-xs", "font-semibold", "uppercase", "tracking-wide", "text-brand-textPrimary", 3, "click"], [1, "mt-1"], ["class", "mt-3 rounded-xl border border-brand-border p-3", 4, "ngIf"], [1, "flex", "flex-col", "gap-3", "sm:flex-row", "sm:items-center", "sm:justify-end"], ["type", "button", 1, "easy-pill-btn", "easy-cta-secondary", "w-full", "min-h-[44px]", "sm:w-auto", 3, "click"], ["type", "button", 1, "easy-pill-btn", "easy-cta-primary", "w-full", "min-h-[44px]", "sm:w-auto", 3, "click"], [1, "text-xs", "text-brand-textMuted"], ["routerLink", "/politica-cookies", 1, "underline"], [1, "mt-3", "rounded-xl", "border", "border-brand-border", "p-3"], [1, "flex", "items-center", "justify-between", "gap-4", "text-sm", "font-medium", "text-brand-textPrimary"], ["type", "button", 1, "relative", "inline-flex", "h-6", "w-11", "items-center", "rounded-full", "transition-colors", 3, "click"], [1, "inline-block", "h-4", "w-4", "rounded-full", "bg-white", "transition-transform"]],
      template: function CookieBannerComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "section", 1)(2, "div", 2)(3, "div")(4, "h2", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](6, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "p", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](9, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "div", 5)(11, "div", 6)(12, "span", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](14, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "span", 8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](16);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](17, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "p");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](19);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](20, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](21, "div", 9)(22, "div", 6)(23, "span", 7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](24);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](25, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](26, "button", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CookieBannerComponent_Template_button_click_26_listener() {
            return ctx.togglePreferences();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](27);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](28, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](29, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](30, "p", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](31);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](32, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](33, CookieBannerComponent_div_33_Template, 7, 14, "div", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](34, "div", 13)(35, "button", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CookieBannerComponent_Template_button_click_35_listener() {
            return ctx.acceptEssential();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](36);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](37, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](38, "button", 15);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CookieBannerComponent_Template_button_click_38_listener() {
            return ctx.acceptAll();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](39);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](40, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](41, "p", 16)(42, "a", 17);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](43);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](44, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](6, 12, "cookies.banner.title", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](48, _c1)), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](9, 15, "cookies.banner.body", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](49, _c3)), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](14, 18, "cookies.categories.essential", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](50, _c4)), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](17, 21, "cookies.state.required", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](51, _c5)), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](20, 24, "cookies.categories.essential_desc", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](52, _c7)), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](25, 27, "cookies.categories.analytics", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](53, _c8)), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", ctx.showPreferences ? _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](28, 30, "cookies.action.hide", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](54, _c9)) : _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](29, 33, "cookies.action.configure", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](55, _c10)), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](32, 36, "cookies.categories.analytics_desc", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](56, _c12)), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.showPreferences);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](37, 39, "cookies.action.essential_only", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](57, _c13)), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](40, 42, "cookies.action.accept_all", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](58, _c14)), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](44, 45, "cookies.action.policy", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](59, _c15)), " ");
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterLink, _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__.TranslatePipe],
      styles: ["[_nghost-%COMP%] {\n  position: fixed;\n  inset: 0;\n  z-index: 50;\n  pointer-events: none;\n}\n\n.cookie-overlay[_ngcontent-%COMP%] {\n  pointer-events: auto;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvb2tpZS1iYW5uZXIuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQWU7RUFDZixRQUFRO0VBQ1IsV0FBVztFQUNYLG9CQUFvQjtBQUN0Qjs7QUFFQTtFQUNFLG9CQUFvQjtBQUN0QiIsImZpbGUiOiJjb29raWUtYmFubmVyLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgaW5zZXQ6IDA7XG4gIHotaW5kZXg6IDUwO1xuICBwb2ludGVyLWV2ZW50czogbm9uZTtcbn1cblxuLmNvb2tpZS1vdmVybGF5IHtcbiAgcG9pbnRlci1ldmVudHM6IGF1dG87XG59XG4iXX0= */\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvY29va2llLWJhbm5lci9jb29raWUtYmFubmVyLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxlQUFlO0VBQ2YsUUFBUTtFQUNSLFdBQVc7RUFDWCxvQkFBb0I7QUFDdEI7O0FBRUE7RUFDRSxvQkFBb0I7QUFDdEI7O0FBRUEsd2dCQUF3Z0IiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgaW5zZXQ6IDA7XG4gIHotaW5kZXg6IDUwO1xuICBwb2ludGVyLWV2ZW50czogbm9uZTtcbn1cblxuLmNvb2tpZS1vdmVybGF5IHtcbiAgcG9pbnRlci1ldmVudHM6IGF1dG87XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
    });
  }
}

/***/ }),

/***/ 6841:
/*!**************************************************************************************!*\
  !*** ./src/app/shared/components/cookie-preferences/cookie-preferences.component.ts ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CookiePreferencesComponent: () => (/* binding */ CookiePreferencesComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _core_services_cookie_consent_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../core/services/cookie-consent.service */ 1845);
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ 852);




const _c0 = function () {
  return {
    default: "Preferencias de cookies"
  };
};
const _c1 = "Puedes activar o desactivar las cookies de an\u00E1lisis en cualquier momento. Las cookies esenciales siempre est\u00E1n habilitadas para que el sitio funcione.";
const _c2 = function () {
  return {
    default: _c1
  };
};
const _c3 = function () {
  return {
    default: "Cerrar"
  };
};
const _c4 = function () {
  return {
    default: "Anal\u00EDticas"
  };
};
const _c5 = "Recopilan informaci\u00F3n an\u00F3nima para mejorar nuestro servicio.";
const _c6 = function () {
  return {
    default: _c5
  };
};
class CookiePreferencesComponent {
  constructor(cookieConsent) {
    this.cookieConsent = cookieConsent;
    this.closed = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
  }
  toggleAnalytics() {
    if (this.cookieConsent.analyticsEnabled) {
      this.cookieConsent.rejectAnalytics();
    } else {
      this.cookieConsent.acceptAnalytics();
    }
  }
  close() {
    this.closed.emit();
  }
  static {
    this.ɵfac = function CookiePreferencesComponent_Factory(t) {
      return new (t || CookiePreferencesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_core_services_cookie_consent_service__WEBPACK_IMPORTED_MODULE_0__.CookieConsentService));
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
      type: CookiePreferencesComponent,
      selectors: [["app-cookie-preferences"]],
      outputs: {
        closed: "closed"
      },
      decls: 28,
      vars: 39,
      consts: [[1, "fixed", "inset-0", "z-50", "flex", "items-center", "justify-center", "bg-black/60", "p-4"], [1, "w-full", "max-w-lg", "rounded-3xl", "border", "border-brand-border", "bg-brand-surface", "p-6", "shadow-2xl"], [1, "flex", "items-start", "justify-between", "gap-4"], [1, "text-xl", "font-semibold", "text-brand-textPrimary"], [1, "mt-2", "text-sm", "text-brand-textSecondary"], ["type", "button", 1, "text-brand-textMuted", "hover:text-brand-textPrimary", 3, "click"], [1, "mt-6", "rounded-2xl", "border", "border-brand-borderSubtle", "bg-brand-background", "p-4"], [1, "flex", "flex-wrap", "items-center", "gap-4", "sm:flex-nowrap", "sm:justify-between"], [1, "min-w-0", "flex-1"], [1, "text-base", "font-semibold", "text-brand-textPrimary"], [1, "text-sm", "text-brand-textSecondary"], ["type", "button", 1, "relative", "inline-flex", "h-7", "w-12", "flex-shrink-0", "items-center", "rounded-full", "transition-colors", "self-start", "sm:self-auto", "sm:ml-4", 3, "click"], [1, "inline-block", "h-5", "w-5", "rounded-full", "bg-white", "transition-transform"], [1, "mt-6", "flex", "flex-col", "gap-3", "sm:flex-row", "sm:items-center", "sm:justify-end"], ["type", "button", 1, "easy-pill-btn", "easy-cta-secondary", "w-full", "sm:w-auto", 3, "click"]],
      template: function CookiePreferencesComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div")(4, "h2", 3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](6, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "p", 4);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](8);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](9, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "button", 5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CookiePreferencesComponent_Template_button_click_10_listener() {
            return ctx.close();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](11, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12, " \u2715 ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "div", 6)(14, "div", 7)(15, "div", 8)(16, "p", 9);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](17);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](18, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](19, "p", 10);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](20);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](21, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "button", 11);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CookiePreferencesComponent_Template_button_click_22_listener() {
            return ctx.toggleAnalytics();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](23, "span", 12);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](24, "div", 13)(25, "button", 14);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function CookiePreferencesComponent_Template_button_click_25_listener() {
            return ctx.close();
          });
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](26);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](27, "translate");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](6, 15, "cookies.modal.title", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](33, _c0)), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](9, 18, "cookies.modal.body", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](34, _c2)), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵattribute"]("aria-label", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](11, 21, "cookies.action.close", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](35, _c3)));
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](18, 24, "cookies.categories.analytics", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](36, _c4)), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](21, 27, "cookies.categories.analytics_desc", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](37, _c6)), " ");
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassProp"]("bg-brand-accentPrimary", ctx.cookieConsent.analyticsEnabled)("bg-brand-border", !ctx.cookieConsent.analyticsEnabled);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵattribute"]("aria-pressed", ctx.cookieConsent.analyticsEnabled);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵclassProp"]("translate-x-6", ctx.cookieConsent.analyticsEnabled)("translate-x-1", !ctx.cookieConsent.analyticsEnabled);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind2"](27, 30, "cookies.action.close", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](38, _c3)), " ");
        }
      },
      dependencies: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__.TranslatePipe],
      styles: ["[_nghost-%COMP%] {\n  display: contents;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvb2tpZS1wcmVmZXJlbmNlcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUJBQWlCO0FBQ25CIiwiZmlsZSI6ImNvb2tpZS1wcmVmZXJlbmNlcy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xuICBkaXNwbGF5OiBjb250ZW50cztcbn1cbiJdfQ== */\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvY29va2llLXByZWZlcmVuY2VzL2Nvb2tpZS1wcmVmZXJlbmNlcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsaUJBQWlCO0FBQ25COztBQUVBLHdVQUF3VSIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgZGlzcGxheTogY29udGVudHM7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
    });
  }
}

/***/ }),

/***/ 3277:
/*!********************************************************************!*\
  !*** ./src/app/shared/components/easy-card/easy-card.component.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EasyCardComponent: () => (/* binding */ EasyCardComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7580);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 316);


function EasyCardComponent_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojection"](0);
  }
}
function EasyCardComponent_a_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](0);
  }
}
function EasyCardComponent_a_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "a", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, EasyCardComponent_a_2_ng_container_1_Template, 1, 0, "ng-container", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r2.wrapperClasses);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("href", ctx_r2.normalizedHref, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsanitizeUrl"])("target", ctx_r2.target)("rel", ctx_r2.rel);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("role", ctx_r2.role)("aria-label", ctx_r2.ariaLabel)("aria-labelledby", ctx_r2.ariaLabelledBy)("aria-describedby", ctx_r2.ariaDescribedBy);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", _r0);
  }
}
function EasyCardComponent_div_3_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](0);
  }
}
function EasyCardComponent_div_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, EasyCardComponent_div_3_ng_container_1_Template, 1, 0, "ng-container", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassMap"](ctx_r3.wrapperClasses);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵattribute"]("role", ctx_r3.role)("aria-label", ctx_r3.ariaLabel)("aria-labelledby", ctx_r3.ariaLabelledBy)("aria-describedby", ctx_r3.ariaDescribedBy)("tabindex", ctx_r3.tabIndex);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", _r0);
  }
}
const _c0 = ["*"];
class EasyCardComponent {
  constructor() {
    // Tailwind safelist (do not remove):
    // group block w-full h-full rounded-2xl border border-brand-border bg-brand-surface shadow-lg transition-all duration-300
    // hover:-translate-y-1 hover:bg-brand-surfaceStrong focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-accentPrimary active:scale-[0.99]
    // text-left text-center p-0 p-6
    this.tag = 'div';
    this.interactive = true;
    this.align = 'center';
    this.paddingClass = 'p-6';
  }
  get alignClass() {
    return this.align === 'left' ? 'text-left' : 'text-center';
  }
  get baseClasses() {
    return ['rounded-2xl', 'border', 'border-brand-border', 'bg-brand-surface', 'shadow-lg', 'transition-all', 'duration-300'].join(' ');
  }
  get interactiveClasses() {
    if (!this.interactive) {
      return '';
    }
    return ['hover:-translate-y-1', 'hover:bg-brand-surfaceStrong', 'focus-visible:outline-none', 'focus-visible:ring-2', 'focus-visible:ring-brand-accentPrimary', 'active:scale-[0.99]'].join(' ');
  }
  get wrapperClasses() {
    return ['group', 'block', 'w-full', 'h-full', this.baseClasses, this.alignClass, this.paddingClass, this.interactiveClasses].filter(Boolean).join(' ');
  }
  get tabIndex() {
    if (this.tag === 'div' && this.interactive) {
      return '0';
    }
    return null;
  }
  get normalizedHref() {
    if (this.tag !== 'a') {
      return null;
    }
    return this.href ?? '#';
  }
  static {
    this.ɵfac = function EasyCardComponent_Factory(t) {
      return new (t || EasyCardComponent)();
    };
  }
  static {
    this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
      type: EasyCardComponent,
      selectors: [["app-easy-card"]],
      inputs: {
        tag: ["as", "tag"],
        href: "href",
        target: "target",
        rel: "rel",
        role: "role",
        ariaLabel: "ariaLabel",
        ariaLabelledBy: "ariaLabelledBy",
        ariaDescribedBy: "ariaDescribedBy",
        interactive: "interactive",
        align: "align",
        paddingClass: "paddingClass"
      },
      ngContentSelectors: _c0,
      decls: 4,
      vars: 2,
      consts: [["content", ""], [3, "href", "target", "rel", "class", 4, "ngIf"], [3, "class", 4, "ngIf"], [3, "href", "target", "rel"], [4, "ngTemplateOutlet"]],
      template: function EasyCardComponent_Template(rf, ctx) {
        if (rf & 1) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵprojectionDef"]();
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, EasyCardComponent_ng_template_0_Template, 1, 0, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, EasyCardComponent_a_2_Template, 2, 10, "a", 1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, EasyCardComponent_div_3_Template, 2, 8, "div", 2);
        }
        if (rf & 2) {
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.tag === "a");
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
          _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.tag === "div");
        }
      },
      dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgTemplateOutlet],
      styles: ["/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlYXN5LWNhcmQuY29tcG9uZW50LmNzcyJ9 */\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvZWFzeS1jYXJkL2Vhc3ktY2FyZC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFDQSxvS0FBb0siLCJzb3VyY2VSb290IjoiIn0= */"]
    });
  }
}

/***/ }),

/***/ 5312:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   environment: () => (/* binding */ environment)
/* harmony export */ });
/* harmony import */ var _firebase_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./firebase.config */ 8654);

const environment = {
  production: false,
  firebaseConfig: _firebase_config__WEBPACK_IMPORTED_MODULE_0__.firebaseConfig
};

/***/ }),

/***/ 8654:
/*!*********************************************!*\
  !*** ./src/environments/firebase.config.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   firebaseConfig: () => (/* binding */ firebaseConfig)
/* harmony export */ });
const firebaseConfig = {
  apiKey: 'FIREBASE_API_KEY',
  authDomain: 'FIREBASE_AUTH_DOMAIN',
  projectId: 'FIREBASE_PROJECT_ID',
  storageBucket: 'FIREBASE_STORAGE_BUCKET',
  messagingSenderId: 'FIREBASE_MESSAGING_SENDER_ID',
  appId: 'FIREBASE_APP_ID',
  measurementId: 'FIREBASE_MEASUREMENT_ID'
};

/***/ }),

/***/ 4429:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ 436);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 635);


_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__.platformBrowser().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule).catch(err => console.error(err));

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(886), __webpack_exec__(4429)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map