(function () {
  if (typeof window === "undefined") {
    return;
  }

  window.EASY_LOCKER_GOOGLE_PLACE_ID = window.EASY_LOCKER_GOOGLE_PLACE_ID || "";
  window.EASY_LOCKER_GOOGLE_API_KEY = window.EASY_LOCKER_GOOGLE_API_KEY || "";
})();
